# import pandas as pd
# from neo4j import GraphDatabase
# from sentence_transformers import SentenceTransformer

# # ------------------------------
# # 1. Load model
# # ------------------------------
# model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

# # ------------------------------
# # 2. Load Neo4j config
# # ------------------------------
# def load_config(path="config.txt"):
#     config = {}
#     with open(path) as f:
#         for line in f:
#             key, value = line.strip().split("=")
#             config[key] = value
#     return config

# config = load_config()

# driver = GraphDatabase.driver(
#     config["URI"],
#     auth=(config["USERNAME"], config["PASSWORD"])
# )

# # ------------------------------
# # 3. Fetch journeys
# # ------------------------------
# def fetch_journeys():
#     cypher = """
#     MATCH (j:Journey)
#     RETURN 
#         j.feedback_ID AS feedback_ID,
#         j.food_satisfaction_score AS food,
#         j.arrival_delay_minutes AS delay,
#         j.actual_flown_miles AS miles,
#         j.number_of_legs AS legs,
#         j.passenger_class AS class
#     """

#     with driver.session() as session:
#         return pd.DataFrame(session.run(cypher).data())

# df = fetch_journeys()
# print(f"Fetched journeys: {len(df)}")

# # ------------------------------
# # 4. Create TEXT for semantic embedding
# # ------------------------------
# def journey_to_text(row):
#     return (
#         f"Journey {row['feedback_ID']}. "
#         f"Passenger class {row['passenger_class']}. "
#         f"Food satisfaction {row['food']}. "
#         f"Arrival delay {row['delay']} minutes."
#     )

# df["journey_text"] = df.apply(journey_to_text, axis=1)

# # ✅ 384-D semantic embeddings
# df["embedding_minilm"] = df["journey_text"].apply(
#     lambda t: model.encode(t).tolist()
# )

# # ------------------------------
# # 5. Numeric feature vector (NO transformer)
# # ------------------------------
# CLASS_ENCODING = {"Economy":0, "Premium Economy":1, "Business":2, "First":3}




# def create_numeric_vector(row):
#     return [
#         float(row["food"]),
#         float(row["delay"]),
#         float(row["miles"]),
#         float(row["legs"]),
#         float(CLASS_ENCODING.get(row["passenger_class"], 0))
#     ]

# df["embedding_numeric"] = df.apply(create_numeric_vector, axis=1)

# # ------------------------------
# # 6. Store BOTH embeddings
# # ------------------------------
# def store_embeddings(tx, row):
#     tx.run("""
#         MATCH (j:Journey {feedback_ID: $id})
#         SET
#             j.embedding_minilm   = $minilm,
#             j.embedding_numeric  = $numeric
#     """,
#     id=row["feedback_ID"],
#     minilm=row["embedding_minilm"],
#     numeric=row["embedding_numeric"]
#     )

# with driver.session() as session:
#     for _, row in df.iterrows():
#         session.execute_write(store_embeddings, row.to_dict())
#         print("Stored embeddings for:", row["feedback_ID"])

# print("✅ DONE — semantic + numeric embeddings stored")



import pandas as pd
import numpy as np
from neo4j import GraphDatabase
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

# ------------------------------
# 1. Load model
# ------------------------------
model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

# ------------------------------
# 2. Load Neo4j config
# ------------------------------
def load_config(path="config.txt"):
    config = {}
    with open(path) as f:
        for line in f:
            key, value = line.strip().split("=")
            config[key] = value
    return config

config = load_config()

driver = GraphDatabase.driver(
    config["URI"],
    auth=(config["USERNAME"], config["PASSWORD"])
)

# ------------------------------
# 3. Fetch journeys (for embedding creation)
# ------------------------------
def fetch_journeys():
    cypher = """
    MATCH (j:Journey)
    RETURN 
        j.feedback_ID AS feedback_ID,
        j.food_satisfaction_score AS food,
        j.arrival_delay_minutes AS delay,
        j.actual_flown_miles AS miles,
        j.number_of_legs AS legs,
        j.passenger_class AS passenger_class
    """

    with driver.session() as session:
        return pd.DataFrame(session.run(cypher).data())

# ------------------------------
# 4. Create TEXT for semantic embedding
# ------------------------------
def journey_to_text(row):
    return (
        f"Journey {row['feedback_ID']}. "
        f"Passenger class {row['passenger_class']}. "
        f"Food satisfaction {row['food']}. "
        f"Arrival delay {row['delay']} minutes."
    )

# ------------------------------
# 5. Numeric feature vector
# ------------------------------
CLASS_ENCODING = {"Economy":0, "Premium Economy":1, "Business":2, "First":3}

def create_numeric_vector(row):
    return [
        float(row["food"]),
        float(row["delay"]),
        float(row["miles"]),
        float(row["legs"]),
        float(CLASS_ENCODING.get(row["passenger_class"], 0))
    ]

# ------------------------------
# 6. Store embeddings
# ------------------------------
def store_embeddings(tx, row):
    tx.run("""
        MATCH (j:Journey {feedback_ID: $id})
        SET
            j.embedding_minilm   = $minilm,
            j.embedding_numeric  = $numeric
    """,
    id=row["feedback_ID"],
    minilm=row["embedding_minilm"],
    numeric=row["embedding_numeric"]
    )

# ==========================================================
# 🔍 7. RUN EMBEDDING SEARCH (THIS IS WHAT UI NEEDS)
# ==========================================================
def run_embedding_search(user_query: str, top_k: int = 5):
    """
    Semantic retrieval using MiniLM embeddings stored in Neo4j
    """
    query_vec = model.encode(user_query)

    cypher = """
    MATCH (j:Journey)
    WHERE j.embedding_minilm IS NOT NULL
    RETURN
        j.feedback_ID AS feedback_ID,
        j.arrival_delay_minutes AS delay,
        j.passenger_class AS passenger_class,
        j.embedding_minilm AS embedding
    """

    with driver.session() as session:
        rows = session.run(cypher).data()

    results = []
    for r in rows:
        emb = np.array(r["embedding"])
        score = cosine_similarity([query_vec], [emb])[0][0]

        results.append({
            "feedback_ID": r["feedback_ID"],
            "delay": r["delay"],
            "passenger_class": r["passenger_class"],
            "score": float(score),
            "source": "embedding"
        })

    # Rank by semantic similarity
    results.sort(key=lambda x: x["score"], reverse=True)

    return results[:top_k]

# ==========================================================
# 8. OPTIONAL: RUN ONCE TO CREATE EMBEDDINGS
# ==========================================================
if __name__ == "__main__":
    df = fetch_journeys()
    print(f"Fetched journeys: {len(df)}")

    df["journey_text"] = df.apply(journey_to_text, axis=1)
    df["embedding_minilm"] = df["journey_text"].apply(
        lambda t: model.encode(t).tolist()
    )
    df["embedding_numeric"] = df.apply(create_numeric_vector, axis=1)

    with driver.session() as session:
        for _, row in df.iterrows():
            session.execute_write(store_embeddings, row.to_dict())
            print("Stored embeddings for:", row["feedback_ID"])

    print("✅ DONE — embeddings stored")
