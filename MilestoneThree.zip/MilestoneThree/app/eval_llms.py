import time
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM, pipeline
from query_pipeline import full_pipeline_hybrid

# =========================================================
# 1. CONFIG: FREE LOCAL MODELS (NO API, NO TOKEN)
# =========================================================
MODELS = {
    "flan-t5-small": "google/flan-t5-small",
    "flan-t5-base": "google/flan-t5-base",
    "t5-small": "t5-small",
}

# =========================================================
# 2. PROMPT BUILDER (Context / Persona / Task)
# =========================================================
def build_prompt(context: str, user_query: str) -> str:
    return f"""
### CONTEXT
The following information was retrieved from a flight knowledge graph:
{context}

### PERSONA
You are a flight information assistant.
You must ONLY use the provided context.
If the context is empty, say that no information was found.

### TASK
Answer the following user question clearly and concisely.

User Question:
{user_query}

Answer:
"""

# =========================================================
# 3. FORMAT KG RESULTS INTO CONTEXT
# =========================================================
def kg_results_to_context(results: list) -> str:
    if not results:
        return "No relevant KG results were found."

    lines = []
    for r in results:
        # Use fields that exist in your Journey/Flight nodes
        origin = r.get("origin") or r.get("departure_airport") or "Unknown"
        destination = r.get("destination") or r.get("arrival_airport") or "Unknown"
        delay = r.get("avg_delay") or r.get("arrival_delay_minutes") or "N/A"
        food = r.get("food_satisfaction_score")
        cls = r.get("passenger_class")
        
        line = f"Route {origin} → {destination} with delay {delay} min"
        if food is not None:
            line += f", food score: {food}"
        if cls is not None:
            line += f", class: {cls}"
        lines.append(line)
    return "\n".join(lines)

# =========================================================
# 4. LOAD MODEL PIPELINE
# =========================================================
def load_model(model_name: str):
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSeq2SeqLM.from_pretrained(model_name)

    return pipeline(
        "text2text-generation",
        model=model,
        tokenizer=tokenizer,
        max_new_tokens=256,
    )

# =========================================================
# 5. EVALUATE ONE MODEL
# =========================================================
def run_model(model_id: str, user_query: str, context: str):
    print(f"\nCalling {model_id} ...")
    generator = load_model(MODELS[model_id])

    prompt = build_prompt(context, user_query)

    start = time.time()
    output = generator(prompt)[0]["generated_text"]
    runtime = time.time() - start

    return {
        "model": model_id,
        "answer": output.strip(),
        "response_time_sec": round(runtime, 2),
        "prompt_length_chars": len(prompt),
    }

# =========================================================
# 6. MAIN EVALUATION LOOP
# =========================================================
def evaluate_llms(test_queries):
    results = []

    for q in test_queries:
        print("\n" + "=" * 60)
        print("User Query:", q)

        # Run KG + embedding pipeline
        pipeline_output = full_pipeline_hybrid(q)
        kg_context = kg_results_to_context(pipeline_output["merged_results"])

        print("\nKG Context:\n", kg_context)

        for model_id in MODELS:
            try:
                res = run_model(model_id, q, kg_context)
                results.append(res)

                print("\nModel:", res["model"])
                print("Response time (sec):", res["response_time_sec"])
                print("Answer:\n", res["answer"])

            except Exception as e:
                print(f"Model {model_id} failed:", e)

    return results

# =========================================================
# 7. ENTRY POINT
# =========================================================
if __name__ == "__main__":
    # Example queries using real airport codes from your Neo4j data
    test_questions = [
        "Flights from CRX to NGX with delay under 20 min",
        "Which routes have the lowest arrival delays?",
        "Are there flights from YEX to XPX with minimal delay?"
    ]

    evaluate_llms(test_questions)
