# test_pipeline.py
from preprocessing import preprocess_airline_query, generate_cypher_query
from query_pipeline import full_pipeline_hybrid
from query_runner import format_results

# -------------------------------
# 1. Define representative test queries
# -------------------------------
test_queries = [
    "Flights from CAI to DXB with delay under 20 min",   # delay_query
    "Show me the worst-rated business class flights",    # worst_performing_query
    "Best food in economy class",                        # satisfaction_query
    "Top 5 routes with most flights",                    # route_query
    "Flights with shortest delays",                      # delay_query
    "Flights with seat comfort rating above 8.5",       # satisfaction_query
    "Best flights for multi-leg journeys",              # multi_leg_analysis
    "Average miles by loyalty program",                  # general_query
    "Recommend the most reviewed flights",              # recommendation_query
]

# -------------------------------
# 2. Run tests
# -------------------------------
for q in test_queries:
    print("\n" + "="*60)
    print("User Query:", q)
    
    # Step 1: Preprocessing
    parsed = preprocess_airline_query(q)
    print("Intent:", parsed["intent"])
    print("Entities:", parsed["entities"])
    
    # Step 2: Cypher generation
    cypher_dict = generate_cypher_query(parsed["intent"], parsed["entities"])
    print("Cypher Query:\n", cypher_dict["cypher"])
    print("Params:", cypher_dict["params"])
    
    # Step 3: Full pipeline
    output = full_pipeline_hybrid(q)
    print("\nBaseline Results:")
    print(format_results(output["baseline_results"]))
    
    print("\nEmbedding Results:")
    print(format_results(output["embedding_results"]))
    
    print("\nMerged Results:")
    print(format_results(output["merged_results"]))
    
print("\n" + "="*60)
print("All tests completed!")
