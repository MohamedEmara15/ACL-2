# import pandas as pd
# from neo4j import GraphDatabase
# from sentence_transformers import SentenceTransformer
# from sklearn.preprocessing import StandardScaler

# # ------------------------------
# # 1️⃣ Load Neo4j Config & Connect
# # ------------------------------
# def load_config(path="config.txt"):
#     config = {}
#     with open(path) as f:
#         for line in f:
#             k, v = line.strip().split("=")
#             config[k] = v
#     return config

# config = load_config()
# driver = GraphDatabase.driver(config["URI"], auth=(config["USERNAME"], config["PASSWORD"]))

# # ------------------------------
# # 2️⃣ Load Embedding Model
# # ------------------------------
# model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

# # ------------------------------
# # 3️⃣ Class encoding
# # ------------------------------
# CLASS_ENCODING = {"Economy":0, "Premium Economy":1, "Business":2, "First":3}

# # ------------------------------
# # 4️⃣ Fetch journeys
# # ------------------------------
# def fetch_journeys():
#     cypher = """
#     MATCH (j:Journey)
#     RETURN 
#         j.feedback_ID AS feedback_ID,
#         j.feedback_text AS feedback_text,
#         j.food_satisfaction_score AS food,
#         j.arrival_delay_minutes AS delay,
#         j.actual_flown_miles AS miles,
#         j.number_of_legs AS legs,
#         j.passenger_class AS class
#     """
#     with driver.session() as session:
#         return pd.DataFrame(session.run(cypher).data())

# # ------------------------------
# # 5️⃣ Prepare embeddings
# # ------------------------------
# def prepare_embeddings(df):
    
#     # numeric encoding
#     def encode_row(r):
#         return [
#             float(r["food"]),
#             float(r["delay"]),
#             float(r["miles"]),
#             float(r["legs"]),
#             float(CLASS_ENCODING.get(r["class"], 0))
#         ]
    
#     df["numeric_vector"] = df.apply(encode_row, axis=1)

#     scaler = StandardScaler()
#     df["numeric_scaled"] = list(scaler.fit_transform(df["numeric_vector"].tolist()))

#     # text embedding
#     df["embedding_minilm"] = df["feedback_text"].fillna("").apply(lambda x: model.encode(x).tolist())

#     return df

# # ------------------------------
# # 6️⃣ Store embeddings in Neo4j
# # ------------------------------
# def store_embeddings(tx, row):
#     tx.run("""
#         MATCH (j:Journey {feedback_ID: $fid})
#         SET j.embedding_numeric = $numeric,
#             j.embedding_minilm = $text
#     """, fid=row["feedback_ID"],
#          numeric=row["numeric_scaled"],
#          text=row["embedding_minilm"])

# def store_all_embeddings(df):
#     with driver.session() as session:
#         for _, row in df.iterrows():
#             session.execute_write(store_embeddings, row.to_dict())

# # ------------------------------
# # 7️⃣ Vector Search (TEXT)
# # ------------------------------
# def vector_search_text(query_vec, top_k=5):
#     cypher = """
#     MATCH (j:Journey)
#     WHERE j.embedding_minilm IS NOT NULL
#     WITH j, gds.similarity.cosine(j.embedding_minilm, $query_vec) AS sim
#     ORDER BY sim DESC
#     LIMIT $top_k
#     RETURN j.feedback_ID AS id,
#            j.passenger_class AS class,
#            j.food_satisfaction_score AS food,
#            j.arrival_delay_minutes AS delay,
#            sim
#     """
#     with driver.session() as session:
#         return session.run(cypher, query_vec=query_vec, top_k=top_k).data()

# # ------------------------------
# # 8️⃣ Full Pipeline
# # ------------------------------
# def full_pipeline(user_query, top_k=5):
#     df = fetch_journeys()
#     df = prepare_embeddings(df)
#     store_all_embeddings(df)

#     query_vec = model.encode(user_query).tolist()
#     return vector_search_text(query_vec=query_vec, top_k=top_k)

# # ------------------------------
# # 9️⃣ Test
# # ------------------------------
# if __name__ == "__main__":
#     query = "Flights with long delays"
#     results = full_pipeline(query)

#     print("Top results:")
#     for r in results:
#         print(r)



# query_pipeline.py

import pandas as pd
from neo4j import GraphDatabase
from sentence_transformers import SentenceTransformer

# ------------------------------
# 1️⃣ Load Neo4j Config
# ------------------------------
def load_config(path="config.txt"):
    config = {}
    with open(path) as f:
        for line in f:
            k, v = line.strip().split("=")
            config[k] = v
    return config

config = load_config()
driver = GraphDatabase.driver(config["URI"], auth=(config["USERNAME"], config["PASSWORD"]))

# ------------------------------
# 2️⃣ Load Embedding Model
# ------------------------------
model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

# ------------------------------
# 3️⃣ Vector Search (using existing DB embeddings)
# ------------------------------
def vector_search_text(query_text, top_k=5):
    query_vec = model.encode(query_text).tolist()

    cypher = """
    MATCH (j:Journey)
    WHERE j.embedding_minilm IS NOT NULL
    WITH j, gds.similarity.cosine(j.embedding_minilm, $query_vec) AS sim
    ORDER BY sim DESC
    LIMIT $top_k
    RETURN j.feedback_ID AS id,
           j.passenger_class AS class,
           j.food_satisfaction_score AS food,
           j.arrival_delay_minutes AS delay,
           sim
    """
    
    with driver.session() as session:
        result = session.run(cypher, query_vec=query_vec, top_k=top_k)
        return result.data()

# ------------------------------
# 4️⃣ Full Pipeline
# ------------------------------
def full_pipeline(user_query):
    return vector_search_text(user_query, top_k=5)

# ------------------------------
# 5️⃣ TEST
# ------------------------------
if __name__ == "__main__":
    query = "Flights with long arrival delays"
    output = full_pipeline(query)

    print("\nTop results:")
    for r in output:
        print(r)
