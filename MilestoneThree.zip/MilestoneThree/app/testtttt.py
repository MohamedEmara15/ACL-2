# # tests/test_hybrid_pipeline.py
# """
# End-to-end test of HYBRID RETRIEVAL PIPELINE:
# 1. Intent classification
# 2. Entity extraction
# 3. Text embedding
# 4. Baseline Cypher KG retrieval
# 5. Embedding similarity search
# 6. Hybrid ranking
# """

# import re
# from neo4j import GraphDatabase
# from sentence_transformers import SentenceTransformer
# import numpy as np

# # ================================
# # 1️⃣  DATABASE CONNECTION
# # ================================
# driver = GraphDatabase.driver(
#     "neo4j+s://e6ef6a97.databases.neo4j.io", 
#     auth=("neo4j", "dbxYcVd4zNKgp80TYL5qHe4GV8xdYRRgPJptmD7xDUI")
# )

# # ================================
# # 2️⃣  EMBEDDING MODEL
# # ================================
# embedder = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")


# # ==================================================
# # 3️⃣ INTENT CLASSIFIER (RULE-BASED)
# # ==================================================
# def classify_intent(text: str) -> str:

#     text = text.lower()

#     if "delay" in text or "late" in text:
#         return "delay_query"

#     if "food" in text or "meal" in text:
#         return "food_query"

#     if "satisfaction" in text or "happy" in text:
#         return "satisfaction_query"

#     if "recommend" in text or "similar" in text:
#         return "similarity_search"

#     return "generic_search"


# # ==================================================
# # 4️⃣ ENTITY EXTRACTION (REGEX + RULES)
# # ==================================================
# def extract_entities(text: str):

#     airports = re.findall(r"\b[A-Z]{3}\b", text)
#     numbers = re.findall(r"\b\d+\b", text)

#     return {
#         "airports": airports or None,
#         "numbers": numbers or None
#     }


# # ==================================================
# # 5️⃣ BASELINE CYPHER QUERY LIBRARY (10 templates)
# # ==================================================
# QUERY_LIBRARY = {
#     "delay_query": """
#         MATCH (j:Journey)
#         WHERE j.arrival_delay_minutes IS NOT NULL
#         RETURN j.feedback_ID AS id, j.arrival_delay_minutes AS delay
#         ORDER BY delay DESC LIMIT 5
#     """,

#     "food_query": """
#         MATCH (j:Journey)
#         RETURN j.feedback_ID AS id, j.food_satisfaction_score AS food
#         ORDER BY food DESC LIMIT 5
#     """,

#     "satisfaction_query": """
#         MATCH (j:Journey)
#         RETURN j.feedback_ID AS id, j.overall_satisfaction_score AS score
#         ORDER BY score DESC LIMIT 5
#     """,

#     "generic_search": """
#         MATCH (j:Journey)
#         RETURN j.feedback_ID AS id, j.passenger_class AS class
#         LIMIT 5
#     """,

#     # If user asks for similarity → no Cypher needed, fallback
#     "similarity_search": None
# }


# def run_baseline(intent: str):
#     """Runs the Cypher query based on detected intent."""
#     cypher = QUERY_LIBRARY.get(intent)

#     if cypher is None:
#         return []

#     with driver.session() as session:
#         result = session.run(cypher)
#         return [record.data() for record in result]


# # ==================================================
# # 6️⃣  VECTOR SEARCH
# # ==================================================
# def vector_search(user_text, top_k=5):

#     u_emb = embedder.encode(user_text).tolist()

#     with driver.session() as session:

#         result = session.run("""
#             CALL db.index.vector.queryNodes(
#                 'journey_index',
#                 $k,
#                 $embedding
#             ) YIELD node, score
#             RETURN node.feedback_ID AS id,
#                    node.passenger_class AS class,
#                    node.food_satisfaction_score AS food,
#                    node.arrival_delay_minutes AS delay,
#                    score AS sim
#             """,
#             {"k": top_k, "embedding": u_emb}
#         )

#         return [record.data() for record in result]


# # ==================================================
# # 7️⃣ HYBRID MERGE
# # ==================================================
# def hybrid_merge(baseline, semantic):

#     # Convert list -> dict by id
#     combined = {}

#     for b in baseline:
#         combined[b["id"]] = {"baseline": 1.0, "semantic": 0.0, "data": b}

#     for s in semantic:
#         if s["id"] not in combined:
#             combined[s["id"]] = {"baseline": 0.0, "semantic": s["sim"], "data": s}
#         else:
#             combined[s["id"]]["semantic"] = s["sim"]

#     # Hybrid scoring
#     for item in combined.values():
#         item["score"] = 0.6 * item["baseline"] + 0.4 * item["semantic"]

#     # Sort
#     ranked = sorted(combined.values(), key=lambda x: x["score"], reverse=True)

#     return ranked[:5]


# # ==================================================
# # 8️⃣ MAIN END-TO-END TEST
# # ==================================================
# def test_hybrid_pipeline(user_input):

#     print("\n==============================")
#     print(f"🧪 TESTING INPUT: {user_input}")
#     print("==============================\n")

#     # Step 1: Intent
#     intent = classify_intent(user_input)
#     print(f"📌 Intent → {intent}")

#     # Step 2: Entities
#     entities = extract_entities(user_input)
#     print(f"📌 Entities → {entities}")

#     # Step 3: Baseline Cypher
#     baseline = run_baseline(intent)
#     print(f"📌 Baseline Results → {baseline}")

#     # Step 4: Semantic similarity
#     semantic = vector_search(user_input)
#     print(f"📌 Embedding Results → {semantic}")

#     # Step 5: Hybrid
#     combined = hybrid_merge(baseline, semantic)
#     print("\n===== 🏆 FINAL HYBRID TOP RESULTS =====")
#     for res in combined:
#         print(res)

#     print("\n========================================\n")


# # ==================================================
# # 9️⃣  RUN MULTIPLE TEST CASES
# # ==================================================
# if __name__ == "__main__":

#     TEST_CASES = [
#         "Show me the worst delays",
#         "Which journeys had the best food?",
#         "Find happy passengers",
#         "Recommend similar journeys to this feedback",
#         "Flights delayed from LAX",
#     ]

#     for t in TEST_CASES:
#         test_hybrid_pipeline(t)




# import os
# import requests
# import json
# import time

# HF_TOKEN = os.getenv("HUGGINGFACE_API_TOKEN") or os.getenv("HF_TOKEN")

# print("=== HUGGING FACE DEBUG TOOL ===")
# print("Token Loaded:", "YES" if HF_TOKEN else "NO (NULL)")
# print()

# if not HF_TOKEN:
#     print("⚠️ ERROR: No HF token found in environment variables.")
#     print("Add this to your terminal before running:")
#     print('export HUGGINGFACE_API_TOKEN="YOUR_TOKEN_HERE"')
#     exit()

# HEADERS = {"Authorization": f"Bearer {HF_TOKEN}"}

# MODELS = [
#     "google/flan-t5-small",
#     "google/flan-t5-base",
#     "t5-small",
# ]

# def test_model(model_id):
#     print(f"\n=== Testing Model: {model_id} ===")

#     url = f"https://api-inference.huggingface.co/models/{model_id}"

#     payload = {
#         "inputs": "Test prompt: translate 'Hello' to French.",
#         "parameters": {"max_new_tokens": 20}
#     }

#     try:
#         t0 = time.time()
#         r = requests.post(url, headers=HEADERS, json=payload)
#         t1 = time.time()

#         print("Status Code:", r.status_code)
#         print("Response Time:", round(t1 - t0, 2), "seconds")

#         if r.status_code != 200:
#             print("❌ Error Response:")
#             print(r.text)
#         else:
#             print("✅ Model responded successfully:")
#             print(json.dumps(r.json(), indent=2))

#     except Exception as e:
#         print("❌ Exception occurred:", str(e))


# print("=== STARTING MODEL CHECK ===")
# for m in MODELS:
#     test_model(m)

# print("\n=== Debug Complete ===")



# llm_hybrid_evaluator.py
import os
import time
import json
from typing import List, Dict, Any, Optional
import pandas as pd

from llm_layer import (
    build_context,
    build_prompt as build_llm_prompt,
    call_hf_local,
    call_openai_chat,
    semantic_similarity_score
)
from query_pipeline import full_pipeline  # Your hybrid KG+embedding pipeline

# -------------------------------
# Free HuggingFace models to compare
# -------------------------------
FREE_MODELS = {
    "flan-t5-small": "google/flan-t5-small",
    "flan-t5-base": "google/flan-t5-base",
    "t5-small": "t5-small",
}

# -------------------------------
# Example test queries
# -------------------------------
TEST_QUERIES = [
    "Flights from CRX to NGX with delay under 20 min",
    "Which routes have the lowest arrival delays?",
    "Are there flights from YEX to XPX with minimal delay?"
]

# -------------------------------
# Evaluate models
# -------------------------------
def evaluate_models(queries: List[str], models: Dict[str,str]):
    results = []
    raw_runs = []

    for q in queries:
        print("\n" + "="*60)
        print("User Query:", q)

        # 1) Get KG + embedding results
        pipeline_output = full_pipeline(q)
        merged_results = pipeline_output.get("merged_results") or []
        context_text = build_context(merged_results)
        print("\nMerged KG Context:\n", context_text[:500], "...\n")

        # 2) Build structured prompt
        prompt = build_llm_prompt(q, merged_results)

        # 3) Run all models
        model_outputs = []
        for model_id, model_name in models.items():
            print(f"Running model: {model_id}")
            start = time.time()
            try:
                out = call_hf_local(prompt, model_name=model_name)
                elapsed = time.time() - start
                output_text = out["text"]
                usage_tokens = len(prompt.split()) + len(output_text.split())

                result = {
                    "query": q,
                    "model": model_id,
                    "response": output_text,
                    "response_time_sec": round(elapsed,2),
                    "token_estimate": usage_tokens
                }
                results.append(result)
                model_outputs.append(result)

                print(f"Answer ({model_id}):\n{output_text}\nTime: {round(elapsed,2)}s, Tokens: {usage_tokens}\n")

            except Exception as e:
                print(f"Model {model_id} failed:", e)
                results.append({"query": q, "model": model_id, "error": str(e)})

        raw_runs.append({
            "query": q,
            "context": merged_results,
            "model_outputs": model_outputs
        })

    # Save CSV and JSON
    pd.DataFrame(results).to_csv("llm_eval_results.csv", index=False)
    with open("llm_eval_results.json","w",encoding="utf-8") as f:
        json.dump(raw_runs,f, indent=2, ensure_ascii=False)

    print("\n✅ Evaluation complete. Saved llm_eval_results.csv and llm_eval_results.json")
    return results, raw_runs

# -------------------------------
# Main entry
# -------------------------------
if __name__ == "__main__":
    evaluate_models(TEST_QUERIES, FREE_MODELS)
