# # llm_layer.py
# import time
# import os
# import json
# from typing import List, Dict, Any, Optional
# from sentence_transformers import SentenceTransformer
# import numpy as np

# # Try to import OpenAI; if not present, wrapper will skip it gracefully
# try:
#     import openai
# except Exception:
#     openai = None

# # Try transformers for local HF models
# try:
#     from transformers import pipeline, AutoTokenizer, AutoModelForSeq2SeqLM, AutoModelForCausalLM
# except Exception:
#     pipeline = None

# # Use same embedding model you already use for retrieval
# embedder = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

# # ---------------------------
# # 1) Build context from merged results
# # ---------------------------
# def build_context(merged_results: List[Dict[str, Any]], max_items: int = 20) -> str:
#     """
#     Convert merged KG results into a compact, human-readable context block
#     Prefer the most informative keys: origin/destination/flight_id/avg_delay/avg_food/score/feedback_ID
#     """
#     if not merged_results:
#         return "No relevant KG results were found."

#     lines = []
#     for i, r in enumerate(merged_results[:max_items]):
#         # canonicalize keys for readability
#         parts = []
#         if "origin" in r and "destination" in r:
#             parts.append(f"Route: {r['origin']}→{r['destination']}")
#         if "flight_id" in r:
#             parts.append(f"Flight: {r['flight_id']}")
#         if "avg_delay" in r:
#             parts.append(f"avg_delay_mins: {round(r['avg_delay'],2)}")
#         if "avg_food" in r:
#             parts.append(f"avg_food_rating: {round(r['avg_food'],2)}")
#         if "review_count" in r:
#             parts.append(f"reviews: {r['review_count']}")
#         if "feedback_ID" in r or "feedback_Id" in r or "feedbackId" in r:
#             fid = r.get("feedback_ID") or r.get("feedback_Id") or r.get("feedbackId")
#             parts.append(f"journey_feedback_id: {fid}")
#         if "score" in r:
#             parts.append(f"sim_score: {round(r['score'],4)}")
#         # fallback: include any other small keys
#         for k,v in r.items():
#             if k in ["origin","destination","flight_id","avg_delay","avg_food","review_count","feedback_ID","score"]: 
#                 continue
#             if isinstance(v,(str,int,float)) and len(str(v))<80:
#                 parts.append(f"{k}:{v}")
#         lines.append(" | ".join(parts))
#     return "\n".join(lines)


# # ---------------------------
# # 2) Prompt Template builder
# # ---------------------------
# PERSONA = "You are a helpful, factual airline analytics assistant."

# TASK_INSTRUCTIONS = (
#     "Use ONLY the provided database context items below to answer the user's question. "
#     "If the information needed is not present in the context, say 'Not enough data to answer'. "
#     "Do not hallucinate. Be concise and show which KG items you used (by quoting short fragments)."
# )

# def build_prompt(user_query: str, merged_results: List[Dict[str,Any]]) -> str:
#     context = build_context(merged_results)
#     prompt = (
#         f"CONTEXT:\n{context}\n\n"
#         f"PERSONA:\n{PERSONA}\n\n"
#         f"TASK:\n{TASK_INSTRUCTIONS}\n\n"
#         f"USER QUESTION:\n{user_query}\n\n"
#         f"ANSWER (grounded strictly on CONTEXT):"
#     )
#     return prompt


# # ---------------------------
# # 3) Model wrappers
# #   We provide three model-call methods:
# #    - OpenAI ChatCompletion (if OPENAI_API_KEY)
# #    - HuggingFace local (transformers pipeline) - e.g., flan-t5-base or similar seq2seq
# #    - HuggingFace Inference HTTP (if HF_TOKEN) as fallback
# # ---------------------------

# def call_openai_chat(prompt: str, model: str="gpt-3.5-turbo", temperature: float=0.0, max_tokens:int=512) -> Dict[str,Any]:
#     if openai is None:
#         raise RuntimeError("openai package not installed")
#     key = os.environ.get("OPENAI_API_KEY")
#     if not key:
#         raise RuntimeError("OPENAI_API_KEY not set")
#     openai.api_key = key
#     t0 = time.time()
#     resp = openai.ChatCompletion.create(
#         model=model,
#         messages=[{"role":"user","content":prompt}],
#         temperature=temperature,
#         max_tokens=max_tokens
#     )
#     t1 = time.time()
#     usage = resp.get("usage", {})
#     text = resp["choices"][0]["message"]["content"]
#     return {"model":"openai:"+model, "text":text, "time": t1-t0, "usage": usage}


# def call_hf_local(prompt: str, model_name: str="google/flan-t5-base", max_new_tokens:int=256) -> Dict[str,Any]:
#     if pipeline is None:
#         raise RuntimeError("transformers not installed")
#     # choose seq2seq or causal depending on model type
#     # For safety we try seq2seq first
#     t0 = time.time()
#     try:
#         gen = pipeline("text2text-generation", model=model_name, device=0 if os.environ.get("USE_CUDA","0")=="1" else -1)
#         out = gen(prompt, max_length=max_new_tokens, do_sample=False)
#         text = out[0]["generated_text"]
#     except Exception as e:
#         # try causal
#         gen = pipeline("text-generation", model=model_name, device=0 if os.environ.get("USE_CUDA","0")=="1" else -1)
#         out = gen(prompt, max_new_tokens)
#         text = out[0]["generated_text"]
#     t1 = time.time()
#     return {"model":"hf_local:"+model_name, "text": text, "time": t1-t0, "usage": {}}


# def call_hf_inference_api(prompt: str, model_name: str="google/flan-t5-large", max_new_tokens:int=256) -> Dict[str,Any]:
#     """
#     Uses HuggingFace Inference API (requires HF_TOKEN). This is an HTTP call — we provide a simple implementation.
#     """
#     import requests
#     HF_TOKEN = os.environ.get("HUGGINGFACE_API_TOKEN")
#     if not HF_TOKEN:
#         raise RuntimeError("HUGGINGFACE_API_TOKEN not set")
#     headers = {"Authorization": f"Bearer {HF_TOKEN}"}
#     API = f"https://api-inference.huggingface.co/models/{model_name}"
#     payload = {"inputs": prompt, "parameters": {"max_new_tokens": max_new_tokens}}
#     t0 = time.time()
#     r = requests.post(API, headers=headers, json=payload, timeout=60)
#     t1 = time.time()
#     if r.status_code != 200:
#         raise RuntimeError(f"HF inference error {r.status_code}: {r.text}")
#     data = r.json()
#     # returned structure varies, handle common case
#     if isinstance(data, list) and "generated_text" in data[0]:
#         text = data[0]["generated_text"]
#     elif isinstance(data, dict) and "error" in data:
#         raise RuntimeError("HF error: " + data["error"])
#     else:
#         # fallback
#         text = str(data)
#     return {"model":"hf_api:"+model_name, "text":text, "time": t1-t0, "usage":{}}


# # ---------------------------
# # 4) Multi-model answer function
# # ---------------------------
# def answer_with_model(user_query: str, merged_results: List[Dict[str,Any]], model_runner: str="openai", model_name: Optional[str]=None) -> Dict[str,Any]:
#     """
#     model_runner in {"openai", "hf_local", "hf_api"}.
#     model_name is the model id for that runner (e.g., "gpt-3.5-turbo" or "google/flan-t5-base")
#     """
#     prompt = build_prompt(user_query, merged_results)

#     if model_runner == "openai":
#         model_name = model_name or os.environ.get("OPENAI_DEFAULT_MODEL","gpt-3.5-turbo")
#         return call_openai_chat(prompt, model=model_name)
#     if model_runner == "hf_local":
#         model_name = model_name or "google/flan-t5-base"
#         return call_hf_local(prompt, model_name=model_name)
#     if model_runner == "hf_api":
#         model_name = model_name or "google/flan-t5-large"
#         return call_hf_inference_api(prompt, model_name=model_name)
#     raise ValueError("Unknown model_runner")
    

# # ---------------------------
# # 5) Simple semantic-quality proxy using embeddings
# # ---------------------------
# def semantic_similarity_score(response_text: str, reference_text: str) -> float:
#     """
#     Returns cosine similarity between embeddings of response and reference.
#     This is a proxy for semantic closeness (0..1)
#     """
#     a = embedder.encode([response_text])[0]
#     b = embedder.encode([reference_text])[0]
#     a = np.array(a); b = np.array(b)
#     sim = float(np.dot(a,b) / (np.linalg.norm(a)*np.linalg.norm(b)))
#     return sim

# # ---------------------------
# # 6) Small helper to pretty-print the KG context used
# # ---------------------------
# def pretty_context(merged_results):
#     return build_context(merged_results)


# llm_layer.py
# llm_layer_hf.py
from typing import List, Dict
from query_runner import build_kg_context
from transformers import AutoTokenizer, AutoModelForCausalLM, AutoModelForSeq2SeqLM, pipeline

# ------------------------------
# 1️⃣ HuggingFace Models (Public, Free)
# ------------------------------
HF_MODELS = [
    
    "google/flan-t5-small",   # ~80M parameters, fast on CPU
    #"sshleifer/tiny-gpt2",    # Tiny GPT2 model, very fast
    "google/flan-t5-base"     # Medium size, still OK on CPU

        # T5 instruction-tuned, small
]

# ------------------------------
# 2️⃣ Combine KG Results
# ------------------------------
def combine_kg_results(baseline_results: List[Dict], embedding_results: List[Dict]) -> str:
    """
    Merge structured Cypher results and embedding-based retrievals
    into a single unified context for LLM.
    """
    context = build_kg_context(baseline_results, embedding_results)
    return context

# ------------------------------
# 3️⃣ Build LLM Prompt
# ------------------------------
def build_prompt(context: str, persona: str, task: str) -> str:
    """
    Structure the LLM prompt with three sections:
    - Context: KG information
    - Persona: Assistant role
    - Task: Instruction
    """
    prompt = f"""
Context:
{context}

Persona:
{persona}

Task:
{task}
"""
    return prompt.strip()

# ------------------------------
# 4️⃣ Load HuggingFace Model
# ------------------------------
def load_hf_model(model_name: str, max_new_tokens=512):
    """
    Load a HuggingFace model and return a text-generation pipeline
    Handles causal and seq2seq models automatically.
    """
    tokenizer = AutoTokenizer.from_pretrained(model_name)

    if "t5" in model_name.lower():
        model = AutoModelForSeq2SeqLM.from_pretrained(model_name)
        hf_pipeline = pipeline("text2text-generation", model=model, tokenizer=tokenizer, max_new_tokens=max_new_tokens)
    else:
        model = AutoModelForCausalLM.from_pretrained(model_name)
        hf_pipeline = pipeline("text-generation", model=model, tokenizer=tokenizer, max_new_tokens=max_new_tokens)

    return hf_pipeline

# ------------------------------
# 5️⃣ Query HuggingFace LLM
# ------------------------------
def query_llm(prompt: str, hf_pipeline) -> str:
    """
    Send structured prompt to the HF pipeline and return the answer.
    """
    result = hf_pipeline(prompt, max_new_tokens=512, do_sample=False)
    # Extract generated text
    if isinstance(result, list) and "generated_text" in result[0]:
        return result[0]["generated_text"]
    elif isinstance(result, list) and "text" in result[0]:
        return result[0]["text"]
    return str(result)

# ------------------------------
# 6️⃣ Full LLM Layer Pipeline
# ------------------------------
def llm_pipeline(
    baseline_results: List[Dict],
    embedding_results: List[Dict],
    persona: str = "You are a helpful flight information assistant",
    task: str = "Provide a concise answer using only the facts explicitly stated in the context. Do not repeat the context.",
    model_name: str = HF_MODELS[0]
) -> str:
    # 1. Combine KG results
    context = combine_kg_results(baseline_results, embedding_results)

    # 2. Build structured prompt
    prompt = build_prompt(context, persona, task)

    # 3. Load model
    hf_pipeline = load_hf_model(model_name)

    # 4. Query LLM
    answer = query_llm(prompt, hf_pipeline)

    return answer

# ------------------------------
# 7️⃣ Example Usage
# ------------------------------
if __name__ == "__main__":
    from query_runner import run_cypher_query, vector_search_numeric

    # Example KG queries
    baseline_results = run_cypher_query("MATCH (f:Flight) RETURN f.flight_number AS flight_id LIMIT 3")
    embedding_results = vector_search_numeric([0.1]*384, k=3)  # dummy embedding for testing

    for model in HF_MODELS:
        print(f"\n=== Testing model: {model} ===")
        response = llm_pipeline(
            baseline_results,
            embedding_results,
            persona="You are a helpful flight information assistant",
            task="Answer the user's question using only the provided information",
            model_name=model
        )
        print("LLM Answer:\n", response)
