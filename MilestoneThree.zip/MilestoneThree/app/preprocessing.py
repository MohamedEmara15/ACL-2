#preprocessing
import re
from sentence_transformers import SentenceTransformer
from typing import Dict, List, Any , Tuple
from query_runner import run_cypher_query

# Load once at startup — saves time & memory
embedding_model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

# ===============================================
# 1. INTENT CLASSIFICATION — Airline Theme
# ===============================================
def classify_intent_airline(text: str) -> str:
    text = text.lower()

    # 1️⃣ Strong qualifiers first (worst / best)
    if any(w in text for w in ["worst", "poorest", "lowest", "most delayed", "bad"]):
        if any(w in text for w in ["food", "meal", "service", "comfort"]):
            return "worst_satisfaction_query"
        return "worst_performing_query"

    # 2️⃣ Delay analysis
    if any(w in text for w in ["delay", "late", "ontime", "on-time", "punctuality"]):
        if any(w in text for w in ["route", "from", "to"]):
            return "route_delay_query"
        return "delay_query"

    # 3️⃣ Satisfaction / food / comfort
    if any(w in text for w in ["satisfaction", "rating", "food", "seat", "comfort", "service", "crew"]):
        return "satisfaction_query"

    # 4️⃣ Class-level comparisons
    if any(w in text for w in ["business", "first class", "economy", "premium"]):
        if "worst" in text:
            return "class_comparison_worst"
        return "class_comparison"

    # 5️⃣ Route frequency / connectivity
    if any(w in text for w in ["route", "airport", "connection"]):
        return "route_query"

    # 6️⃣ Recommendations (non-worst, non-delay)
    if any(w in text for w in ["recommend", "best", "top", "good", "great"]):
        return "recommendation_query"

    # 7️⃣ Analysis fallback
    return "general_query"



# ===============================================
# 2. ENTITY EXTRACTION — Airline Theme
# ===============================================
def extract_entities_airline(text: str) -> Dict[str, Any]:
    text_lower = text.lower()
    entities = {}
    
    # Airport codes (3-letter IATA) — very common pattern
    airport_pattern = r'\b([A-Z]{3})\b'
    airports = re.findall(airport_pattern, text)
    if "from" in text_lower and "to" in text_lower:
        try:
            from_idx = text_lower.index("from")
            to_idx = text_lower.index("to")

            dep = next(a for a in airports if text_lower.index(a.lower()) > from_idx)
            arr = next(a for a in airports if text_lower.index(a.lower()) > to_idx)

            entities["departure_airport"] = dep
            entities["arrival_airport"] = arr
        except StopIteration:
            pass
    
    # Flight class
    if any(c in text_lower for c in ["business", "first class", "first-class"]):
        entities["flight_class"] = "Business" if "business" in text_lower else "First"
    elif "economy" in text_lower or "economic" in text_lower:
        entities["flight_class"] = "Economy"
    
    # Delay threshold
    delay_match = re.search(r'less than (\d+) min|under (\d+) min|below (\d+) min|delay[^<]*< (\d+)', text_lower)
    if delay_match:
        entities["max_delay_minutes"] = int(next((x for x in delay_match.groups() if x), 30))
    
    # Rating threshold
    rating_match = re.search(r'rating[^\d]*(\d+\.?\d*)', text)
    if rating_match:
        entities["min_satisfaction"] = float(rating_match.group(1))
    
    return entities


# ===============================================
# 3. INPUT EMBEDDING (for hybrid retrieval)
# ===============================================
def get_query_embedding(text: str) -> List[float]:
    return embedding_model.encode(text).tolist()


# ===============================================
# MAIN PREPROCESSING FUNCTION
# ===============================================
def preprocess_airline_query(user_query: str) -> Dict[str, Any]:
    return {
        "original_query": user_query,
        "intent": classify_intent_airline(user_query),
        "entities": extract_entities_airline(user_query),
        "embedding": get_query_embedding(user_query) if True else None,  # toggle as needed
        "theme": "airline"
    }

# ===============================================
# 4. Cypher Query Generator (Milestone 3)
# ===============================================


def generate_cypher_query(intent: str, entities: dict) -> dict:
    cypher = ""
    params = {}

    # -------------------------------
    # 1) MOST COMMON ROUTES
    # -------------------------------
    if intent == "route_query":
        cypher = """
        MATCH (f:Flight)-[:DEPARTS_FROM]->(a1:Airport),
              (f)-[:ARRIVES_AT]->(a2:Airport)
        RETURN a1.station_code AS origin,
               a2.station_code AS destination,
               COUNT(f) AS flight_count
        ORDER BY flight_count DESC
        LIMIT 5
        """

    # -------------------------------
    # 2) BEST (SHORTEST) DELAYS
    # -------------------------------
    elif intent == "delay_query":
        cypher = """
        MATCH (j:Journey)-[:ON]->(f:Flight),
              (f)-[:DEPARTS_FROM]->(a1:Airport),
              (f)-[:ARRIVES_AT]->(a2:Airport)
        """
        if "max_delay_minutes" in entities:
            cypher += "WHERE j.arrival_delay_minutes <= $max_delay\n"
            params["max_delay"] = entities["max_delay_minutes"]

        cypher += """
        RETURN a1.station_code AS origin,
               a2.station_code AS destination,
               AVG(j.arrival_delay_minutes) AS avg_delay
        ORDER BY avg_delay ASC
        LIMIT 10
        """

    # -------------------------------
    # 3) WORST DELAYS
    # -------------------------------
    elif intent == "worst_performing_query":
        cypher = """
        MATCH (j:Journey)-[:ON]->(f:Flight)
        RETURN f.flight_number AS flight_id,
               AVG(j.arrival_delay_minutes) AS avg_delay
        ORDER BY avg_delay DESC
        LIMIT 10
        """

    # -------------------------------
    # 4) BEST FOOD OVERALL
    # -------------------------------
    elif intent == "satisfaction_query":
        if "flight_class" in entities:
            cypher = """
            MATCH (j:Journey)-[:ON]->(f:Flight)
            WHERE j.passenger_class = $flight_class
            RETURN f.flight_number AS flight_id,
                   AVG(j.food_satisfaction_score) AS avg_food
            ORDER BY avg_food DESC
            LIMIT 10
            """
            params["flight_class"] = entities["flight_class"]
        else:
            cypher = """
            MATCH (j:Journey)-[:ON]->(f:Flight)
            RETURN f.flight_number AS flight_id,
                   AVG(j.food_satisfaction_score) AS avg_food
            ORDER BY avg_food DESC
            LIMIT 10
            """

    # -------------------------------
    # 5) WORST FOOD OVERALL
    # -------------------------------
    elif intent == "worst_satisfaction_query":
        cypher = """
        MATCH (j:Journey)-[:ON]->(f:Flight)
        RETURN f.flight_number AS flight_id,
               AVG(j.food_satisfaction_score) AS avg_food
        ORDER BY avg_food ASC
        LIMIT 10
        """

    # -------------------------------
    # 6) BEST CLASS COMPARISON
    # -------------------------------
    elif intent == "class_comparison":
        cypher = """
        MATCH (j:Journey)
        RETURN j.passenger_class AS flight_class,
               AVG(j.food_satisfaction_score) AS avg_food
        ORDER BY avg_food DESC
        """

    # -------------------------------
    # 7) WORST CLASS COMPARISON
    # -------------------------------
    elif intent == "class_comparison_worst":
        cypher = """
        MATCH (j:Journey)
        RETURN j.passenger_class AS flight_class,
               AVG(j.food_satisfaction_score) AS avg_food
        ORDER BY avg_food ASC
        """


    elif intent == "route_delay_query":
        cypher = """
        MATCH (j:Journey)-[:ON]->(f:Flight),
              (f)-[:DEPARTS_FROM]->(a1:Airport),
              (f)-[:ARRIVES_AT]->(a2:Airport)
        WHERE a1.station_code = $departure_airport
          AND a2.station_code = $arrival_airport
        """
        params["departure_airport"] = entities.get("departure_airport")
        params["arrival_airport"] = entities.get("arrival_airport")

        if "max_delay_minutes" in entities:
            cypher += " AND j.arrival_delay_minutes <= $max_delay"
            params["max_delay"] = entities["max_delay_minutes"]

        cypher += """
        RETURN a1.station_code AS origin,
               a2.station_code AS destination,
               AVG(j.arrival_delay_minutes) AS avg_delay
        ORDER BY avg_delay ASC
        LIMIT 10
        """


    # -------------------------------
    # 9) AVERAGE MILES BY LOYALTY
    # -------------------------------
    elif intent == "general_query":
        cypher = """
        MATCH (p:Passenger)-[:TOOK]->(j:Journey)
        RETURN p.loyalty_program_level AS loyalty_level,
               AVG(j.actual_flown_miles) AS avg_miles
        ORDER BY avg_miles DESC
        """

    # -------------------------------
    # 10) MOST REVIEWED FLIGHTS
    # -------------------------------
    elif intent == "recommendation_query":
        cypher = """
        MATCH (j:Journey)-[:ON]->(f:Flight)
        RETURN f.flight_number AS flight_id,
               COUNT(j) AS review_count
        ORDER BY review_count DESC
        LIMIT 10
        """

    # -------------------------------
    # 11) MULTI-LEG JOURNEYS
    # -------------------------------
    elif intent == "multi_leg_analysis":
        cypher = """
        MATCH (j:Journey)
        WHERE j.number_of_legs > 1
        RETURN j.number_of_legs AS legs,
               AVG(j.food_satisfaction_score) AS avg_food
        ORDER BY legs DESC
        """

    # -------------------------------
    # FALLBACK
    # -------------------------------
    else:
        cypher = "RETURN 'No matching query template' AS message"

    return {"cypher": cypher, "params": params}




# ===============================================
# 5. Main NLP → Query Pipeline
# ===============================================
def process_user_query(user_query: str) -> Dict[str, Any]:
    parsed = preprocess_airline_query(user_query)

    query_obj = generate_cypher_query(parsed["intent"], parsed["entities"])

    results = run_cypher_query(
        query_obj["cypher"],
        query_obj["params"]
    )

    return {
        "query": parsed["original_query"],
        "intent": parsed["intent"],
        "entities": parsed["entities"],
        "cypher_query": query_obj["cypher"],
        "params": query_obj["params"],
        "results": results
    }
