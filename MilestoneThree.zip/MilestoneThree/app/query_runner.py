# from neo4j import GraphDatabase
# from typing import List, Dict, Any
# import json
# import numpy as np



# # ----------------------------------------
# # 1. Load credentials (same as KG builder)
# # ----------------------------------------
# def load_config(path="config.txt"):
#     config = {}
#     with open(path) as f:
#         for line in f:
#             key, value = line.strip().split("=")
#             config[key] = value
#     return config

# config = load_config()

# driver = GraphDatabase.driver(
#     config["URI"],
#     auth=(config["USERNAME"], config["PASSWORD"])
# )

# # ----------------------------------------
# # 2. Execute a Cypher query safely
# # ----------------------------------------
# # def run_cypher_query(cypher_query: str, params: Dict[str, Any] = None):
# #     with driver.session() as session:
# #         result = session.run(cypher_query, params or {})
# #         return [record.data() for record in result]


# def run_cypher_query(cypher_query: str, params: dict | None = None):
#     if params is None:
#         params = {}

#     # ✅ HARD SAFETY CHECK
#     if not isinstance(params, dict):
#         raise TypeError(f"Params must be dict, got {type(params)}: {params}")

#     with driver.session() as session:
#         result = session.run(cypher_query, parameters=params)
#         return [record.data() for record in result]

# # ----------------------------------------
# # 3. Nicely format the results
# # ----------------------------------------
# def format_results(records: List[Dict]) -> str:
#     return json.dumps(records, indent=4)


# def cosine_distance(a, b):
#     a = np.array(a, dtype=float)
#     b = np.array(b, dtype=float)
#     return 1 - np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))


# def vector_search_minilm(query_vec, k=5):
#     """
#     Vector similarity search over Journey nodes using MiniLM embeddings.
#     Returns top-k most similar journeys.
#     """
#     cypher = """
#     MATCH (j:Journey)
#     WHERE j.embedding_minilm IS NOT NULL
#     WITH j, gds.similarity.cosine(j.embedding_minilm, $query_vec) AS similarity
#     ORDER BY similarity DESC
#     LIMIT $k
#     RETURN 
#         j.feedback_ID AS feedback_id,
#         j.arrival_delay_minutes AS delay,
#         j.food_satisfaction_score AS food,
#         j.passenger_class AS class,
#         similarity
#     """
#     with driver.session() as session:
#         result = session.run(
#             cypher,
#             query_vec=query_vec,
#             k=k
#         )
#         return [dict(r) for r in result]



from neo4j import GraphDatabase
from typing import List, Dict, Any
import json
import numpy as np

# ----------------------------------------
# 1. Load credentials
# ----------------------------------------
def load_config(path="config.txt"):
    config = {}
    with open(path) as f:
        for line in f:
            key, value = line.strip().split("=")
            config[key] = value
    return config

config = load_config()

driver = GraphDatabase.driver(
    config["URI"],
    auth=(config["USERNAME"], config["PASSWORD"])
)

# ----------------------------------------
# 2. Execute a Cypher query safely
# ----------------------------------------
def run_cypher_query(cypher_query: str, params: Dict[str, Any] | None = None):
    """
    Runs a Cypher query and returns results as list of dicts.
    """
    if params is None:
        params = {}

    if not isinstance(params, dict):
        raise TypeError(f"Params must be dict, got {type(params)}: {params}")

    with driver.session() as session:
        result = session.run(cypher_query, parameters=params)

        records = []
        for record in result:
            data = dict(record)
            records.append(data)

        return records

# ----------------------------------------
# 3. Format results (debug / display)
# ----------------------------------------
def format_results(records: List[Dict]) -> str:
    return json.dumps(records, indent=4, default=str)

# ----------------------------------------
# 4. Cosine similarity (fallback, python-side)
# ----------------------------------------
def cosine_distance(a, b):
    a = np.array(a, dtype=float)
    b = np.array(b, dtype=float)
    return 1 - np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

# ----------------------------------------
# 5. Vector similarity search (MiniLM)
# ----------------------------------------
def vector_search_numeric(query_vec, k=5):
    cypher = """
    MATCH (j:Journey)
    WHERE j.embedding_minilm IS NOT NULL
    WITH j, gds.similarity.cosine(j.embedding_minilm, $query_vec) AS similarity
    RETURN
        j.feedback_ID AS feedback_id,
        j.arrival_delay_minutes AS arrival_delay,
        j.food_satisfaction_score AS food_score,
        j.passenger_class AS passenger_class,
        similarity
    ORDER BY similarity DESC
    LIMIT $k
    """

    with driver.session() as session:
        result = session.run(
            cypher,
            parameters={
                "query_vec": query_vec,
                "k": k
            }
        )
        return [dict(r) for r in result]


    # Use the detected embedding property in the similarity query
    cypher = f"""
    MATCH (j:Journey)
    WHERE j.{embedding_prop} IS NOT NULL
    WITH j, gds.similarity.cosine(j.{embedding_prop}, $query_vec) AS similarity
    ORDER BY similarity DESC
    LIMIT $k
    RETURN
        j.feedback_ID AS feedback_id,
        j.arrival_delay_minutes AS arrival_delay,
        j.food_satisfaction_score AS food_score,
        j.passenger_class AS passenger_class,
        similarity
    """

    with driver.session() as session:
        result = session.run(
            cypher,
            parameters={
                "query_vec": query_vec,
                "k": k
            }
        )
        return [dict(r) for r in result]

# ----------------------------------------
# 6. Build KG context for LLM ✅ IMPORTANT
# ----------------------------------------
# def build_kg_context(baseline_results, embedding_results=None):
#     if not baseline_results:
#         return "No relevant KG results were found."

#     lines = []
#     for r in baseline_results:
#         flight = r.get("flight")
#         delay = r.get("delay")
#         cls = r.get("class")

#         line = f"Flight {flight} ({cls}) has an arrival delay of {delay} minutes."
#         lines.append(line)

#     return "\n".join(lines)

from typing import List, Dict, Any

def build_kg_context(results: List[Dict[str, Any]], intent: str) -> str:
    if not results:
        return "No relevant KG results were found."

    lines = []

    # --------------------------------------------------
    # 1) WORST / BEST DELAYS (flight-level)
    # --------------------------------------------------
    if intent in ["worst_performing_query"]:
        for r in results:
            flight = r.get("flight_id")
            delay = r.get("avg_delay")
            if flight is not None and delay is not None:
                lines.append(
                    f"Flight {flight} has an average arrival delay of {round(delay, 2)} minutes."
                )

    # --------------------------------------------------
    # 2) ROUTE DELAY QUERY (ORD → LAX etc.)
    # --------------------------------------------------
    elif intent in ["route_delay_query", "delay_query"]:
        for r in results:
            origin = r.get("origin")
            destination = r.get("destination")
            avg_delay = r.get("avg_delay")
            if origin and destination and avg_delay is not None:
                lines.append(
                    f"Flights from {origin} to {destination} have an average arrival delay of {round(avg_delay, 2)} minutes."
                )

    # --------------------------------------------------
    # 3) SATISFACTION (FOOD / SERVICE)
    # --------------------------------------------------
    elif intent in ["satisfaction_query", "worst_satisfaction_query"]:
        for r in results:
            flight = r.get("flight_id")
            score = r.get("avg_food")
            if flight is not None and score is not None:
                lines.append(
                    f"Flight {flight} has an average food satisfaction score of {round(score, 2)}."
                )

    # --------------------------------------------------
    # 4) CLASS COMPARISON
    # --------------------------------------------------
    elif intent in ["class_comparison", "class_comparison_worst"]:
        for r in results:
            flight_class = r.get("flight_class")
            avg_food = r.get("avg_food")
            if flight_class and avg_food is not None:
                lines.append(
                    f"Passengers in {flight_class} class have an average food satisfaction score of {round(avg_food, 2)}."
                )

    # --------------------------------------------------
    # 5) ROUTE FREQUENCY
    # --------------------------------------------------
    elif intent == "route_query":
        for r in results:
            origin = r.get("origin")
            destination = r.get("destination")
            count = r.get("flight_count")
            if origin and destination and count is not None:
                lines.append(
                    f"There are {count} flights operating from {origin} to {destination}."
                )

    # --------------------------------------------------
    # 6) RECOMMENDATIONS (MOST REVIEWED)
    # --------------------------------------------------
    elif intent == "recommendation_query":
        for r in results:
            flight = r.get("flight_id")
            reviews = r.get("review_count")
            if flight is not None and reviews is not None:
                lines.append(
                    f"Flight {flight} has {reviews} passenger reviews."
                )

    # --------------------------------------------------
    # 7) GENERAL QUERY (LOYALTY / MILES)
    # --------------------------------------------------
    elif intent == "general_query":
        for r in results:
            level = r.get("loyalty_level")
            miles = r.get("avg_miles")
            if level and miles is not None:
                lines.append(
                    f"Passengers with loyalty level {level} fly an average of {round(miles, 2)} miles."
                )

    # --------------------------------------------------
    # 8) MULTI-LEG ANALYSIS
    # --------------------------------------------------
    elif intent == "multi_leg_analysis":
        for r in results:
            legs = r.get("legs")
            avg_food = r.get("avg_food")
            if legs is not None and avg_food is not None:
                lines.append(
                    f"Journeys with {legs} legs have an average food satisfaction score of {round(avg_food, 2)}."
                )

    # --------------------------------------------------
    # FALLBACK (SAFE)
    # --------------------------------------------------
    else:
        return "KG results were retrieved, but could not be formatted for this query."

    return "\n".join(lines) if lines else "No relevant KG results were found."


def build_embedding_context(embedding_results):
    if not embedding_results:
        return "No relevant embedding results were found."

    lines = []

    for r in embedding_results:
        lines.append(
            f"Journey {r.get('id')} | "
            f"Class: {r.get('class')} | "
            f"Delay: {r.get('delay')} min | "
            f"Food Satisfaction: {r.get('food')} | "
            f"Similarity Score: {round(r.get('sim', 0), 3)}"
        )

    return "\n".join(lines)



     # Embedding (semantic)
    for r in embedding_results:
        fid = r.get("feedback_id")
        delay = r.get("arrival_delay")
        cls = r.get("passenger_class")

        if fid:
            context_lines.append(
                f"Journey feedback {fid} (class: {cls}) reports "
                f"arrival delay of {delay} minutes."
            )

    if not context_lines:
        return "No relevant KG results were found."

    return "\n".join(context_lines)
