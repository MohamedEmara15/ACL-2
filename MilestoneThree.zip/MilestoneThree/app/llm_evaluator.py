# import os
# import time
# import json
# import requests
# import pandas as pd
# from typing import List, Dict, Any

# # ==============================
# # CONFIG
# # ==============================
# HF_TOKEN = os.getenv("HUGGINGFACE_API_TOKEN")
# if not HF_TOKEN:
#     raise RuntimeError("Set your HF token in env var HUGGINGFACE_API_TOKEN")

# HEADERS = {"Authorization": f"Bearer {HF_TOKEN}"}

# # Free HF models for evaluation
# HF_MODELS = [
#     "HuggingFaceH4/zephyr-7b-beta",
#     "mistralai/Mistral-7B-Instruct-v0.2",
#     "google/gemma-2-2b-it"
# ]

# HF_API_BASE = "https://router.huggingface.co/v1/completions"

# # Sample queries for testing
# TEST_QUERIES = [
#     "Flights from CRX to NGX with delay under 20 min",
#     "Which routes have the lowest arrival delays?",
#     "Are there flights from YEX to XPX with minimal delay?"
# ]

# PERSONA = "You are a flight information assistant. Be factual and concise."
# TASK = "Answer the user's question using ONLY the provided CONTEXT. If insufficient data, respond exactly: 'Not enough data to answer'."

# # ==============================
# # HELPER FUNCTIONS
# # ==============================
# def merge_and_format_context(baseline_results: List[Dict[str, Any]],
#                              embedding_results: List[Dict[str, Any]],
#                              top_n: int = 20) -> List[Dict[str, Any]]:
#     """Merge baseline (structured) + embedding (semantic) results safely."""
#     merged = []
#     seen = set()

#     for source in [baseline_results, embedding_results]:
#         if not isinstance(source, list):
#             continue
#         for item in source:
#             if not isinstance(item, dict):
#                 continue
#             cid = item.get("flight_id") or f"{item.get('origin')}->{item.get('destination')}" or item.get("feedback_id")
#             if cid and cid not in seen:
#                 merged.append(item)
#                 seen.add(cid)

#     return merged[:top_n]

# def build_context_text(merged_results: List[Dict[str, Any]]) -> str:
#     """Convert merged KG+embedding results into a compact LLM-readable text."""
#     if not merged_results:
#         return "No relevant KG results were found."
#     lines = []
#     for r in merged_results:
#         parts = []
#         if "flight_id" in r: parts.append(f"Flight {r['flight_id']}")
#         if "origin" in r and "destination" in r: parts.append(f"Route {r['origin']}→{r['destination']}")
#         if "avg_delay" in r: parts.append(f"avg_delay={r['avg_delay']}min")
#         if "arrival_delay" in r: parts.append(f"delay={r.get('arrival_delay')}min")
#         if "review_count" in r: parts.append(f"reviews={r['review_count']}")
#         if "feedback_id" in r: parts.append(f"feedback={r['feedback_id']}")
#         lines.append(" | ".join(parts) if parts else str(r))
#     return "\n".join(lines)

# def build_prompt(context: str, query: str) -> str:
#     return f"""
# ### CONTEXT
# {context}

# ### PERSONA
# {PERSONA}

# ### TASK
# {TASK}

# QUESTION:
# {query}

# ANSWER (use only the CONTEXT; if insufficient data, reply exactly: 'Not enough data to answer'):
# """

# def call_hf_model(model_id: str, prompt: str, max_tokens: int = 256) -> Dict[str, Any]:
#     payload = {
#         "model": model_id,
#         "prompt": prompt,
#         "max_tokens": max_tokens,
#         "temperature": 0.0
#     }
#     t0 = time.time()
#     resp = requests.post(HF_API_BASE, headers=HEADERS, json=payload)
#     t1 = time.time()

#     if resp.status_code != 200:
#         raise RuntimeError(f"HF API error for {model_id}: {resp.status_code} - {resp.text}")

#     data = resp.json()
#     text = data.get("choices", [{}])[0].get("text", "")
#     return {"response_text": text.strip(), "elapsed_sec": t1-t0, "raw_response": data}

# def approx_token_count(text: str) -> int:
#     return int(len(text.split()) * 1.3)

# # ==============================
# # MAIN EVALUATION
# # ==============================
# def evaluate_queries(queries: List[str],
#                      models: List[str],
#                      baseline_results: Dict[str, List[Dict[str, Any]]]=None,
#                      embedding_results: Dict[str, List[Dict[str, Any]]]=None):
#     results = []
#     raw = {"runs": []}

#     baseline_results = baseline_results or {}
#     embedding_results = embedding_results or {}

#     for query in queries:
#         print(f"\n=== Query: {query}")
#         baseline = baseline_results.get(query, [])
#         embedding = embedding_results.get(query, [])
#         merged = merge_and_format_context(baseline, embedding)
#         context_text = build_context_text(merged)
#         prompt = build_prompt(context_text, query)

#         model_results = []
#         for model in models:
#             print(f"→ Model: {model}")
#             try:
#                 res = call_hf_model(model, prompt)
#                 row = {
#                     "query": query,
#                     "model": model,
#                     "response": res["response_text"],
#                     "time_sec": res["elapsed_sec"],
#                     "input_tokens_est": approx_token_count(prompt),
#                     "output_tokens_est": approx_token_count(res["response_text"])
#                 }
#                 results.append(row)
#                 model_results.append(row)
#                 print(f"✔ OK ({res['elapsed_sec']:.2f}s)")
#             except Exception as e:
#                 print(f"❌ Error: {e}")
#                 row = {"query": query, "model": model, "error": str(e)}
#                 results.append(row)
#                 model_results.append(row)

#         raw["runs"].append({
#             "query": query,
#             "context": merged,
#             "prompt": prompt,
#             "model_results": model_results
#         })

#     df = pd.DataFrame(results)
#     df.to_csv("results_llm_eval.csv", index=False)
#     with open("results_llm_eval.json", "w") as f:
#         json.dump(raw, f, indent=2)
#     print("\nSaved results_llm_eval.csv and results_llm_eval.json")
#     return df, raw

# # ==============================
# # RUN SCRIPT
# # ==============================
# if __name__ == "__main__":
#     # You can prefill KG and embedding results here if available
#     baseline_results_example = {}  # e.g., {"Flights from CRX to NGX...": [{...}, ...], ...}
#     embedding_results_example = {}

#     evaluate_queries(TEST_QUERIES, HF_MODELS, baseline_results_example, embedding_results_example)





"""
llm_openrouter_evaluator.py
LLM Evaluator using OpenRouter (free) for KG+embedding prompts
Requirements:
    pip install requests pandas
Usage:
    1) Set your OpenRouter API key:
        export OPENROUTER_API_KEY="your_key_here"
    2) Run:
        python llm_openrouter_evaluator.py
Outputs:
    - results_llm_eval.csv
    - results_llm_eval.json
"""

import os
import time
import json
import requests
import pandas as pd
from typing import List, Dict, Any

# -------------------------
# CONFIG
# -------------------------
# Free OpenRouter-supported models
OPENROUTER_MODELS = [
    "openrouter/llama-3-7b-chat",
    "openrouter/falcon-7b-instruct",
    "openrouter/mistral-7b-instruct"
]

OPENROUTER_API = "https://openrouter.ai/api/v1/chat/completions"
API_KEY = os.environ.get("OPENROUTER_API_KEY")
if not API_KEY:
    raise RuntimeError("Please set your OPENROUTER_API_KEY environment variable")

HEADERS = {"Authorization": f"Bearer {API_KEY}"}

# -------------------------
# Helpers
# -------------------------
def merge_and_format_context(baseline: List[Dict], embedding: List[Dict], top_n=20) -> List[Dict]:
    merged = []
    seen = set()

    for source in [baseline, embedding]:
        for item in (source or []):
            if not isinstance(item, dict):
                continue
            cid = item.get("flight_id") or f"{item.get('origin')}->{item.get('destination')}" or item.get("feedback_id")
            if cid and cid not in seen:
                merged.append(item)
                seen.add(cid)
    return merged[:top_n]

def build_context_text(data: List[Dict[str, Any]]) -> str:
    if not data:
        return "No relevant KG results found."
    lines = []
    for r in data:
        parts = []
        if r.get("flight_id"): parts.append(f"Flight {r['flight_id']}")
        if r.get("origin") and r.get("destination"): parts.append(f"Route {r['origin']}→{r['destination']}")
        if r.get("avg_delay"): parts.append(f"avg_delay={round(r['avg_delay'],2)}m")
        if r.get("review_count"): parts.append(f"reviews={r['review_count']}")
        lines.append(" | ".join(parts) if parts else str(r))
    return "\n".join(lines)

def build_prompt(context: str, query: str, persona: str, task: str) -> str:
    return f"""
### CONTEXT
{context}

### PERSONA
{persona}

### TASK
{task}

QUESTION:
{query}

ANSWER (use ONLY the context; otherwise say: "Not enough data to answer"):
"""

def call_openrouter_model(model_id: str, prompt: str, max_tokens: int = 256) -> Dict[str, Any]:
    """Call OpenRouter Chat Completion API"""
    payload = {
        "model": model_id,
        "messages": [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt}
        ],
        "max_tokens": max_tokens,
        "temperature": 0.0
    }

    t0 = time.time()
    resp = requests.post(OPENROUTER_API, headers=HEADERS, json=payload, timeout=120)
    t1 = time.time()

    if resp.status_code != 200:
        raise RuntimeError(f"OpenRouter API error for {model_id}: {resp.status_code} - {resp.text}")

    data = resp.json()
    try:
        text = data["choices"][0]["message"]["content"]
    except Exception:
        text = str(data)

    return {"model": model_id, "response_text": text.strip(), "elapsed_sec": t1 - t0, "raw_response": data}

def approx_token_count(text: str) -> int:
    return int(len(text.split()) * 1.3)

# -------------------------
# Main Evaluation
# -------------------------
def evaluate_queries_with_models(queries: List[str], models: List[str], persona: str, task: str):
    results = []
    raw = {"runs": []}

    # Import your KG pipeline if exists
    try:
        from query_pipeline import full_pipeline
        has_pipe = True
    except:
        has_pipe = False
        print("⚠️ No full_pipeline found; using empty KG results.")

    for query in queries:
        print(f"\n=== Query: {query}")

        if has_pipe:
            try:
                pipe = full_pipeline(query)
                baseline = pipe.get("baseline_results", [])
                embedding = pipe.get("embedding_results", [])
                merged = pipe.get("merged_results", [])
            except:
                baseline = embedding = merged = []
        else:
            baseline = embedding = merged = []

        if not merged:
            merged = merge_and_format_context(baseline, embedding)

        context_text = build_context_text(merged)
        prompt = build_prompt(context_text, query, persona, task)

        one_query_results = []

        for model in models:
            print(f"→ Model: {model}")
            try:
                resp = call_openrouter_model(model, prompt)
            except Exception as e:
                print("  ❌ Error:", e)
                results.append({"query": query, "model": model, "error": str(e)})
                one_query_results.append({"model": model, "error": str(e)})
                continue

            row = {
                "query": query,
                "model": model,
                "response": resp["response_text"],
                "time_sec": resp["elapsed_sec"],
                "input_tokens_est": approx_token_count(prompt),
                "output_tokens_est": approx_token_count(resp["response_text"])
            }
            results.append(row)
            one_query_results.append(row)

        raw["runs"].append({"query": query, "context": merged, "prompt": prompt, "model_results": one_query_results})

    # Save results
    df = pd.DataFrame(results)
    df.to_csv("results_llm_eval.csv", index=False)
    with open("results_llm_eval.json", "w") as f:
        json.dump(raw, f, indent=2)

    print("\nSaved results_llm_eval.csv and results_llm_eval.json")
    return df, raw

# -------------------------
# Example Run
# -------------------------
if __name__ == "__main__":
    TEST_QUERIES = [
        "Flights from CRX to NGX with delay under 20 min",
        "Which routes have the lowest arrival delays?",
        "Are there flights from YEX to XPX with minimal delay?"
    ]

    PERSONA = "You are a flight information assistant. Be factual and concise."
    TASK = "Answer ONLY using the context. If insufficient data, answer: 'Not enough data to answer'."

    evaluate_queries_with_models(TEST_QUERIES, OPENROUTER_MODELS, PERSONA, TASK)
