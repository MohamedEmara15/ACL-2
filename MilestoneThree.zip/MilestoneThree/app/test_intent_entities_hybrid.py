# # test_intent_entities_hybrid.py
# from preprocessing import classify_intent_airline, extract_entities_airline, process_user_query
# from hybrid_retrieval import hybrid_intent_selection
# import pprint


# # ------------------------------
# # 1️⃣ Sample queries
# # ------------------------------
# # sample_queries = [
# #     "Show me the worst delays",
# #     "Recommend flights with high food satisfaction",
# #     "Compare business class vs economy",
# #     "Flights arriving late from JFK to LAX",
# #     "Which routes have the most connections?",
# # ]

# # # ------------------------------
# # # 2️⃣ Test each query
# # # ------------------------------
# # for query in sample_queries:
# #     print("\n" + "="*60)
# #     print(f"🧪 TESTING QUERY: {query}")

# #     # Step 1: Intent classification
# #     intent = classify_intent_airline(query)
# #     print(f"📌 Classified Intent → {intent}")

# #     # Step 2: Entity extraction
# #     entities = extract_entities_airline(query)
# #     print(f"📌 Extracted Entities → {entities}")

# #     # Step 3: Hybrid intent (combining embedding similarity)
# #     best_intent, score, all_scores = hybrid_intent_selection(query, detected_intent=intent)
# #     print(f"📌 Hybrid-selected Intent → {best_intent}")
# #     print(f"📌 Intent Scores → {all_scores}")


# # test_baseline.py

# # Sample airline queries for baseline testing


# # sample_queries = [
# #     "Show me the flights with the worst delays",
# #     "Which flights have the best food in business class?",
# #     "Compare economy and business class satisfaction",
# #     "Find flights from ORD to LAX with minimal delays",
# #     "Recommend top flights based on passenger reviews"
# # ]

# # pp = pprint.PrettyPrinter(indent=2)

# # for query in sample_queries:
# #     print("="*50)
# #     print(f"Query: {query}")
# #     try:
# #         result = process_user_query(query)
# #         print("Intent Detected:", result["intent"])
# #         print("Entities Extracted:", result["entities"])
# #         print("Cypher Query:")
# #         print(result["cypher_query"])
# #         print("Params:", result["params"])
# #         print("Results:")
# #         pp.pprint(result["results"])
# #     except Exception as e:
# #         print("Error:", e)
# #     print("="*50 + "\n")

# from query_pipeline import full_pipeline

# query = "Flights with long delays"
# results = full_pipeline(query)

# print("===== EMBEDDING SEARCH RESULTS =====")
# for r in results:
#     print(r)




# test_all_pipeline.py

from query_pipeline import process_user_query
from embedding_pipeline import full_pipeline, hybrid_intent_selection
from preprocessing import preprocess_airline_query
import pprint

# ------------------------------
# 1️⃣ Define test queries
# ------------------------------
TEST_QUERIES = [
    "Show me the flights with the worst delays",
    "Which flights have the best food in business class",
    "Compare economy and business class satisfaction",
    "Find flights from ORD to LAX with minimal delays",
    "Recommend top flights based on passenger reviews",
    "Flights with long arrival delays"
]

pp = pprint.PrettyPrinter(indent=4)

# ------------------------------
# 2️⃣ Run tests
# ------------------------------
for query in TEST_QUERIES:
    print("="*50)
    print(f"Query: {query}")

    # ------------------------------
    # 2a. Preprocessing: intent & entities
    # ------------------------------
    parsed = preprocess_airline_query(query)
    print("Intent Detected:", parsed["intent"])
    print("Entities Extracted:", parsed["entities"])

    # ------------------------------
    # 2b. Baseline Cypher
    # ------------------------------
    baseline_results = process_user_query(query)
    print("\nCypher Query:")
    print(baseline_results["cypher_query"])
    print("Params:", baseline_results["params"])
    print("Baseline Results:")
    pp.pprint(baseline_results["results"])

    # ------------------------------
    # 2c. Embedding search
    # ------------------------------
    embedding_results = full_pipeline(query)
    print("\nTop Embedding Results:")
    pp.pprint(embedding_results)

    # ------------------------------
    # 2d. Hybrid intent selection
    # ------------------------------
    best_intent, score, all_scores = hybrid_intent_selection(
        query, detected_intent=parsed["intent"]
    )
    print("\nHybrid Intent Selected:", best_intent)
    print("Hybrid Scores:")
    pp.pprint(all_scores)

print("="*50)
