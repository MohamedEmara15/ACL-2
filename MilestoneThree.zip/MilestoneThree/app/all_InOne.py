# all_in_one_test.py
import time
from llm_layer import eval_llms, kg_results_to_context, MODELS
from query_pipeline import process_user_query, full_pipeline_hybrid

# ----------------------------
# 1️⃣ Define test queries
# ----------------------------
test_queries = [
    "Show me the flights with the worst delays",
    "Which flights have the best food in business class?",
    "Compare economy and business class satisfaction",
    "Find flights from ORD to LAX with minimal delays",
    "Recommend top flights based on passenger reviews",
]

# ----------------------------
# 2️⃣ Run intent/entity/embedding tests
# ----------------------------
print("\n" + "="*60)
print("STEP 1: Intent, Entities, Cypher Query, KG Results")
print("="*60)

all_pipeline_results = []

for q in test_queries:
    print("\n" + "-"*40)
    print("User Query:", q)
    
    # Run full pipeline (intent + entity + hybrid + Cypher query)
    pipeline_result = full_pipeline_hybrid(q)
    
    print("Detected Intent:", pipeline_result.get("intent"))
    print("Extracted Entities:", pipeline_result.get("entities"))
    print("Cypher Query:\n", pipeline_result.get("cypher_query"))
    print("Params:", pipeline_result.get("params"))
    print("Results:", pipeline_result.get("merged_results"))
    
    all_pipeline_results.append(pipeline_result)

# ----------------------------
# 3️⃣ Run LLM test on same queries
# ----------------------------
print("\n" + "="*60)
print("STEP 2: LLM Answers (grounded on KG + embeddings)")
print("="*60)

for i, q in enumerate(test_queries):
    merged_results = all_pipeline_results[i]["merged_results"]
    context = kg_results_to_context(merged_results)
    
    print("\n" + "-"*40)
    print("User Query:", q)
    print("\nKG Context:\n", context)
    
    # Evaluate all local models
    for model_id in MODELS:
        try:
            res = eval_llms([q])  # Using your existing LLM evaluation
            # Already prints inside evaluate_llms
        except Exception as e:
            print(f"Model {model_id} failed:", e)
