# import streamlit as st
# from query_runner import run_cypher_query, build_kg_context
# from llm_layer import llm_pipeline, HF_MODELS
# import networkx as nx
# import matplotlib.pyplot as plt

# # ------------------------------
# # Page Config
# # ------------------------------
# st.set_page_config(page_title="Graph-RAG Flight Assistant", layout="wide")

# st.title("✈️ Graph-RAG Flight Information Assistant")
# st.markdown("Ask questions grounded in the Knowledge Graph.")

# # ------------------------------
# # Sidebar
# # ------------------------------
# st.sidebar.header("⚙️ Settings")

# retrieval_method = st.sidebar.selectbox(
#     "Retrieval Method",
#     ["Baseline (Cypher)"]  # keep simple for demo
# )

# model_name = st.sidebar.selectbox("LLM Model", HF_MODELS)
# show_cypher = st.sidebar.checkbox("Show Cypher Query", value=True)
# show_graph = st.sidebar.checkbox("Show Graph Visualization", value=True)

# # ------------------------------
# # User Input
# # ------------------------------
# user_question = st.text_input(
#     "💬 Ask a question about flights:",
#     placeholder="Show me the flights with the worst delays"
# )

# # ------------------------------
# # Run
# # ------------------------------
# if st.button("🔍 Run Query") and user_question:

#     # ✅ CORRECT Cypher (matches your KG)
#     cypher_query = """
#     MATCH (j:Journey)-[:ON]->(f:Flight)
#     RETURN f.flight_number AS flight,
#            j.arrival_delay_minutes AS delay,
#            j.passenger_class AS class
#     ORDER BY delay DESC
#     LIMIT 5
#     """

#     baseline_results = run_cypher_query(cypher_query)

#     # ------------------------------
#     # KG Context
#     # ------------------------------
#     kg_context = build_kg_context(baseline_results, [])

#     st.subheader("📦 Retrieved KG Context (Raw)")
#     st.code(kg_context, language="text")

#     if show_cypher:
#         st.subheader("🧠 Cypher Query Executed")
#         st.code(cypher_query, language="cypher")

#     # ------------------------------
#     # Graph Visualization
#     # ------------------------------
#     if show_graph and baseline_results:
#         st.subheader("🕸️ Retrieved Subgraph")

#         G = nx.Graph()
#         for r in baseline_results:
#             flight = f"Flight {r['flight']}"
#             journey = f"Delay {r['delay']} min"
#             G.add_edge(flight, journey)

#         fig, ax = plt.subplots()
#         nx.draw(G, with_labels=True, node_color="lightblue", ax=ax)
#         st.pyplot(fig)

#     # ------------------------------
#     # LLM
#     # ------------------------------
#     st.subheader("🤖 LLM Answer")

#     answer = llm_pipeline(
#         baseline_results=baseline_results,
#         embedding_results=[],
#         persona="You are a helpful flight information assistant",
#         task="Answer the user's question using only the retrieved knowledge graph facts.",
#         model_name=model_name
#     )

#     st.success(answer)




# import streamlit as st
# from query_runner import run_cypher_query, build_kg_context
# from llm_layer import llm_pipeline, HF_MODELS
# import networkx as nx
# import matplotlib.pyplot as plt
# from preprocessing import process_user_query
# from query_pipeline import vector_search_text

# # ------------------------------
# # Page Config
# # ------------------------------
# st.set_page_config(page_title="Graph-RAG Flight Assistant", layout="wide")

# st.title("✈️ Graph-RAG Flight Information Assistant")
# st.markdown("Ask questions grounded in the Knowledge Graph.")

# # ------------------------------
# # Sidebar
# # ------------------------------
# st.sidebar.header("⚙️ Settings")

# retrieval_method = st.sidebar.selectbox(
#     "Retrieval Method",
#     [
#         "Baseline (Cypher)",
#         "Embedding",
#         "Hybrid (Baseline + Embedding)"
#     ]
# )


# model_name = st.sidebar.selectbox("LLM Model", HF_MODELS)
# show_cypher = st.sidebar.checkbox("Show Cypher Query", value=True)
# #show_graph = st.sidebar.checkbox("Show Graph Visualization", value=True)

# # ------------------------------
# # User Input
# # ------------------------------
# user_question = st.text_input(
#     "💬 Ask a question about flights:",
#     placeholder="Show me the flights with the worst delays"
# )

# # ------------------------------
# # Run
# # ------------------------------
# if st.button("🔍 Run Query") and user_question:

#     pipeline_output = process_user_query(user_question)
#     baseline_results = pipeline_output["results"]

#     embedding_results = run_embedding_query(
#     user_question,
#     intent
# )

#     merged_results = merge_results(
#     baseline_results,
#     embedding_results
# )

#     cypher_query = pipeline_output["cypher_query"]
#     intent = pipeline_output["intent"]
#     entities = pipeline_output["entities"]



#     st.subheader("🧭 Detected Intent & Entities")
#     st.json({
#     "intent": intent,
#     "entities": entities
# })



#     # ------------------------------
#     # KG Context
#     # ------------------------------
#     kg_context = build_kg_context(baseline_results, intent)

#     st.subheader("📦 Retrieved KG Context (Raw)")
#     st.code(kg_context, language="text")

#     if show_cypher:
#         st.subheader("🧠 Cypher Query Executed")
#         st.code(cypher_query, language="cypher")

#     # ------------------------------
#     # Graph Visualization
#     # ------------------------------
#     # if show_graph and baseline_results:
#     #     st.subheader("🕸️ Retrieved Subgraph")

#     #     G = nx.Graph()
#     #     for r in baseline_results:
#     #         flight = f"Flight {r['flight']}"
#     #         journey = f"Delay {r['delay']} min"
#     #         G.add_edge(flight, journey)

#     #     fig, ax = plt.subplots()
#     #     nx.draw(G, with_labels=True, node_color="lightblue", ax=ax)
#     #     st.pyplot(fig)

#     # ------------------------------
#     # LLM
#     # ------------------------------
#     st.subheader("🤖 LLM Answer")

#     answer = llm_pipeline(
#     baseline_results=[],
#     embedding_results=[],
#     persona="You are a helpful flight information assistant",
#     task=f"""
# Answer the user's question using ONLY the facts below.

# Knowledge Graph Facts:
# {kg_context}
# """,
#     model_name=model_name
# )


#     st.success(answer)






import streamlit as st
from query_runner import build_kg_context, build_embedding_context
from llm_layer import llm_pipeline, HF_MODELS
from preprocessing import process_user_query
from query_pipeline import vector_search_text

# ------------------------------
# Page Config
# ------------------------------
st.set_page_config(page_title="Graph-RAG Flight Assistant", layout="wide")

st.title("✈️ Graph-RAG Flight Information Assistant")
st.markdown("Ask questions grounded in the Knowledge Graph.")

# ------------------------------
# Sidebar
# ------------------------------
st.sidebar.header("⚙️ Settings")

retrieval_method = st.sidebar.selectbox(
    "Retrieval Method",
    [
        "Baseline (Cypher)",
        "Embedding",
        "Hybrid (Baseline + Embedding)"
    ]
)

model_name = st.sidebar.selectbox("LLM Model", HF_MODELS)
show_cypher = st.sidebar.checkbox("Show Cypher Query", value=True)

# ------------------------------
# User Input
# ------------------------------
user_question = st.text_input(
    "💬 Ask a question about flights:",
    placeholder="Show me the flights with the worst delays"
)

# ------------------------------
# Run Query
# ------------------------------
if st.button("🔍 Run Query") and user_question:

    # ---------- PROCESS USER QUERY ----------
    pipeline_output = process_user_query(user_question)
    baseline_results = pipeline_output.get("results", [])
    cypher_query = pipeline_output.get("cypher_query", "")
    intent = pipeline_output.get("intent", "")
    entities = pipeline_output.get("entities", {})

    # ---------- EMBEDDING SEARCH ----------
    embedding_results = vector_search_text(user_question, top_k=5)

    # ---------- HYBRID MERGE ----------
    if retrieval_method == "Baseline (Cypher)":
        final_results = baseline_results
    elif retrieval_method == "Embedding":
        final_results = embedding_results
    else:  # Hybrid
        seen = set()
        final_results = []
        for r in baseline_results + embedding_results:
            fid = r.get("feedback_ID") or r.get("flight")
            if fid not in seen:
                final_results.append(r)
                seen.add(fid)

    # ------------------------------
    # Display Intent & Entities
    # ------------------------------
    st.subheader("🧭 Detected Intent & Entities")
    st.json({
        "intent": intent,
        "entities": entities
    })

    # ------------------------------
    # Build KG Context
    # ------------------------------
    if retrieval_method == "Baseline (Cypher)":
        kg_context = build_kg_context(baseline_results, intent)
    elif retrieval_method == "Embedding":
        kg_context = build_embedding_context(embedding_results)
    else:  # Hybrid
        kg_context = (
            build_kg_context(baseline_results, intent)
            + "\n\n--- Semantic Similarity Results ---\n\n"
            + build_embedding_context(embedding_results)
        )

    st.subheader("📦 Retrieved KG Context (Raw)")
    st.code(kg_context, language="text")

    if show_cypher and retrieval_method != "Embedding":
        st.subheader("🧠 Cypher Query Executed")
        st.code(cypher_query, language="cypher")

    # ------------------------------
    # LLM Answer
    # ------------------------------
    st.subheader("🤖 LLM Answer")

    answer = llm_pipeline(
        baseline_results=baseline_results,
        embedding_results=embedding_results,
        persona="You are a helpful flight information assistant",
        task=f"""
Answer the user's question using ONLY the facts below.

Knowledge Graph Facts:
{kg_context}
""",
        model_name=model_name
    )

    st.success(answer)

