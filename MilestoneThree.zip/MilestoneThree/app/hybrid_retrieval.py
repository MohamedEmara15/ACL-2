import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

# Load embedding model
model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

# ---------------------------------------------------------
# 1. TEMPLATE INDEX (semantic search space)
# ---------------------------------------------------------
TEMPLATE_INDEX = {
    "route_query": "Find airport-to-airport routes or flight connections",
    "delay_query": "Find flights or routes with high or low arrival delays",
    "satisfaction_query": "Find flights or journeys with high or low passenger satisfaction",
    "class_comparison": "Compare business class, economy class or first class flights",
    "worst_performing_query": "Find the worst performing routes, delays or ratings",
    "recommendation_query": "Recommend best flights, top rated or good routes",
    "general_query": "General airline-related question"
}

# Precompute embeddings
TEMPLATE_EMBEDDINGS = {
    key: model.encode(desc)
    for key, desc in TEMPLATE_INDEX.items()
}


# ---------------------------------------------------------
# 2. Compute embedding similarity
# ---------------------------------------------------------
def compute_semantic_similarity(user_query: str, template_name: str) -> float:
    user_vec = model.encode(user_query)
    temp_vec = TEMPLATE_EMBEDDINGS[template_name]
    sim = cosine_similarity([user_vec], [temp_vec])[0][0]
    return float(sim)


# ---------------------------------------------------------
# 3. HYBRID SCORING
# ---------------------------------------------------------
def hybrid_intent_selection(user_query: str, detected_intent: str):
    scores = {}

    for template_intent in TEMPLATE_INDEX:
        sem_sim = compute_semantic_similarity(user_query, template_intent)

        intent_match = 1.0 if detected_intent == template_intent else 0.0

        # Weighted hybrid score
        hybrid_score = (0.85 * sem_sim) + (0.15 * intent_match)

        
        scores[template_intent] = hybrid_score

    # Pick the highest scoring intent
    best_intent = max(scores, key=scores.get)
    return best_intent, scores[best_intent], scores


# ---------------------------------------------------------
# TEST
# ---------------------------------------------------------
if __name__ == "__main__":
    query = "Which flights usually arrive late?"
    detected_intent = "general_query"  # pretend classifier is confused

    best, score, all_scores = hybrid_intent_selection(query, detected_intent)

    print("\nUser Question:", query)
    print("Classifier detected:", detected_intent)
    print("Hybrid selected intent:", best)
    print("Scores:", all_scores)
