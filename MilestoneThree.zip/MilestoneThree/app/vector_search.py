from neo4j import GraphDatabase
from sentence_transformers import SentenceTransformer

# Load model
model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

# Load Neo4j config
def load_config(path="config.txt"):
    config = {}
    with open(path) as f:
        for line in f:
            k, v = line.strip().split("=")
            config[k] = v
    return config

config = load_config()
driver = GraphDatabase.driver(
    config["URI"],
    auth=(config["USERNAME"], config["PASSWORD"])
)

# Vector search function
def search_journeys(query_text, top_k=5):
    query_embedding = model.encode(query_text).tolist()
    cypher = """
    MATCH (j:Journey)
    WHERE j.embedding_minilm IS NOT NULL
    WITH j, gds.similarity.cosine(j.embedding_minilm, $query_vec) AS sim
    ORDER BY sim DESC
    LIMIT $k
    RETURN j.feedback_ID AS id,
           j.passenger_class AS class,
           j.food_satisfaction_score AS food,
           j.arrival_delay_minutes AS delay,
           sim
    """
    with driver.session() as session:
        result = session.run(cypher, query_vec=query_embedding, k=top_k)
        return result.data()
