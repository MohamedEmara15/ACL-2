import numpy as np
import pandas as pd
from neo4j import GraphDatabase

# ------------------------------
# Neo4j connection
# ------------------------------
config = {}
with open("config.txt") as f:
    for line in f:
        k, v = line.strip().split("=")
        config[k] = v

driver = GraphDatabase.driver(
    config["URI"],
    auth=(config["USERNAME"], config["PASSWORD"])
)

# ------------------------------
# Fetch ONE journey as query
# ------------------------------
def get_query_embedding(feedback_id, model="minilm"):
    prop = "embedding_minilm" if model == "minilm" else "embedding_mpnet"
    query = f"""
    MATCH (j:Journey {{feedback_ID: $id}})
    RETURN j.{prop} AS embedding
    """
    with driver.session() as s:
        result = s.run(query, id=feedback_id).single()
        return result["embedding"]

# ------------------------------
# Vector similarity search
# ------------------------------
def similarity_search(query_vector, k=5, model="minilm"):
    prop = "embedding_minilm" if model == "minilm" else "embedding_mpnet"
    query = f"""
    MATCH (j:Journey)
    WHERE j.{prop} IS NOT NULL
    RETURN j.feedback_ID AS id,
           gds.similarity.cosine(j.{prop}, $query_vec) AS score
    ORDER BY score DESC
    LIMIT $k
    """
    with driver.session() as s:
        result = s.run(query, query_vec=query_vector, k=k)
        return pd.DataFrame(result.data())

# ------------------------------
# RUN TEST
# ------------------------------
if __name__ == "__main__":
    TEST_ID = "F_2008"   # ✅ one of your stored journeys
    TOP_K = 5

    print(f"\n🔍 Query Journey: {TEST_ID}")

    for model in ["minilm", "mpnet"]:
        print(f"\n===== Results using {model.upper()} =====")

        query_emb = get_query_embedding(TEST_ID, model)
        results = similarity_search(query_emb, TOP_K, model)

        print(results)
