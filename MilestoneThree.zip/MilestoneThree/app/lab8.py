# ===============================
# RAG Chatbot using LangChain + FAISS + Streamlit
# CSEN 903 – Lab 8 Graded Task
# ===============================

import streamlit as st
from pypdf import PdfReader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.chains import RetrievalQA
from langchain.llms.base import LLM
from huggingface_hub import InferenceClient
from typing import Optional, List, Any
from pydantic import Field
import os


# -------------------------------
# Custom LangChain LLM Wrapper
# -------------------------------
class GemmaLangChainWrapper(LLM):
    client: Any = Field(...)
    max_tokens: int = 500

    @property
    def _llm_type(self) -> str:
        return "gemma_hf_api"

    def _call(self, prompt: str, stop: Optional[List[str]] = None) -> str:
        response = self.client.chat_completion(
            messages=[{"role": "user", "content": prompt}],
            max_tokens=self.max_tokens,
            temperature=0.2,
        )
        return response.choices[0].message["content"]


# -------------------------------
# Load and process document
# -------------------------------
@st.cache_resource
def load_vectorstore(pdf_path: str):
    reader = PdfReader(pdf_path)
    all_text = ""

    for page in reader.pages:
        text = page.extract_text()
        if text:
            all_text += text + "\n"

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=400,
        chunk_overlap=100
    )

    documents = splitter.create_documents([all_text])

    embedding_model = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )

    vectorstore = FAISS.from_documents(
        documents=documents,
        embedding=embedding_model
    )

    return vectorstore


# -------------------------------
# Streamlit UI
# -------------------------------
st.title("📄 RAG Document Chatbot")
st.write("Ask questions grounded in the provided document.")

#HF_TOKEN = os.getenv("HF_TOKEN")

HF_TOKEN = "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"


if not HF_TOKEN:
    st.error("Hugging Face token not found. Set it as HF_TOKEN environment variable.")
    st.stop()

client = InferenceClient(
    model="google/gemma-2-2b-it",
    token=HF_TOKEN
)

llm = GemmaLangChainWrapper(client=client)

PDF_PATH = "Checklist.pdf"  # PDF must be in same directory

try:
    vectorstore = load_vectorstore(PDF_PATH)
except Exception as e:
    st.error(f"Failed to load PDF: {e}")
    st.stop()

retriever = vectorstore.as_retriever(search_kwargs={"k": 5})

qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    retriever=retriever,
    chain_type="stuff",
    return_source_documents=True
)

user_question = st.text_input("Your question:")

if user_question:
    with st.spinner("Searching the document..."):
        result = qa_chain(user_question)

    st.subheader("✅ Answer")
    st.write(result["result"])

    with st.expander("📚 Retrieved Source Chunks"):
        for i, doc in enumerate(result["source_documents"], 1):
            st.markdown(f"**Chunk {i}:**")
            st.write(doc.page_content[:800])
            st.markdown("---")


st.markdown("---")
st.caption("CSEN 903 – Retrieval Augmented Generation (LangChain + Streamlit)")
