# query_pipeline.py
import pandas as pd
from neo4j import GraphDatabase
from sentence_transformers import SentenceTransformer
from sklearn.preprocessing import StandardScaler

# ------------------------------
# 1️⃣ Load Neo4j Config
# ------------------------------
def load_config(path="config.txt"):
    config = {}
    with open(path) as f:
        for line in f:
            k, v = line.strip().split("=")
            config[k] = v
    return config

config = load_config()
driver = GraphDatabase.driver(
    config["URI"], 
    auth=(config["USERNAME"], config["PASSWORD"])
)

# ------------------------------
# 2️⃣ Load Embedding Model
# ------------------------------
model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

# ------------------------------
# 3️⃣ Class Encoding
# ------------------------------
CLASS_ENCODING = {
    "Economy": 0,
    "Premium Economy": 1,
    "Business": 2,
    "First": 3
}

# -------------------------------------------------
# 4️⃣ Fetch SMALL SAMPLE for testing (FAST)
# -------------------------------------------------
def fetch_small_sample(limit=10):
    cypher = """
    MATCH (j:Journey)
    RETURN 
        j.feedback_ID AS feedback_ID,
        j.food_satisfaction_score AS food,
        j.arrival_delay_minutes AS delay,
        j.actual_flown_miles AS miles,
        j.number_of_legs AS legs,
        j.passenger_class AS class
    LIMIT $limit
    """
    with driver.session() as session:
        result = session.run(cypher, limit=limit)
        return pd.DataFrame(result.data())

# -------------------------------------------------
# 5️⃣ Prepare embeddings for numeric + text
# -------------------------------------------------
def prepare_embeddings(df):
    # Create numeric vector
    def create_vector(row):
        return [
            float(row["food"]),
            float(row["delay"]),
            float(row["miles"]),
            float(row["legs"]),
            float(CLASS_ENCODING.get(row["class"], 0))
        ]

    df["numeric_vector"] = df.apply(create_vector, axis=1)

    scaler = StandardScaler()
    scaled = scaler.fit_transform(list(df["numeric_vector"]))
    df["numeric_vector_scaled"] = list(scaled)

    # Text embedding (MiniLM on synthetic text description)
    df["minilm_input"] = df.apply(
        lambda r: 
        f"food {r['food']} delay {r['delay']} miles {r['miles']} legs {r['legs']} class {r['class']}",
        axis=1
    )

    df["embedding_minilm"] = df["minilm_input"].apply(lambda t: model.encode(t).tolist())

    return df


# -------------------------------------------------
# 6️⃣ Store embeddings into Neo4j
# -------------------------------------------------
def store_embeddings(tx, row):
    tx.run("""
        MATCH (j:Journey {feedback_ID: $id})
        SET j.embedding_numeric = $numeric,
            j.embedding_minilm = $text
    """,
    id=row["feedback_ID"],
    numeric=row["numeric_vector_scaled"],
    text=row["embedding_minilm"]
    )


def store_all_embeddings(df):
    with driver.session() as session:
        for _, row in df.iterrows():
            session.execute_write(store_embeddings, row.to_dict())


# -------------------------------------------------
# 7️⃣ Vector Search (TEXT MODEL)
# -------------------------------------------------
def vector_search_text(query_vec, top_k=5):
    cypher = """
    MATCH (j:Journey)
    WHERE j.embedding_minilm IS NOT NULL
    WITH j, gds.similarity.cosine(j.embedding_minilm, $qv) AS sim
    ORDER BY sim DESC
    LIMIT $top_k
    RETURN 
        j.feedback_ID AS id,
        j.passenger_class AS class,
        j.food_satisfaction_score AS food,
        j.arrival_delay_minutes AS delay,
        sim
    """
    with driver.session() as session:
        result = session.run(cypher, qv=query_vec, top_k=top_k)
        return result.data()


# -------------------------------------------------
# 8️⃣ FULL PIPELINE (SAMPLE TEST)
# -------------------------------------------------
def full_pipeline(user_query):
    print("📌 Fetching small sample (10 journeys)...")
    df = fetch_small_sample(limit=10)

    print("📌 Preparing embeddings...")
    df = prepare_embeddings(df)

    print("📌 Storing embeddings for sample...")
    store_all_embeddings(df)

    print("📌 Running vector search...")
    query_vec = model.encode(user_query).tolist()
    results = vector_search_text(query_vec=query_vec, top_k=5)

    return results


# -------------------------------------------------
# 9️⃣ TEST RUN
# -------------------------------------------------
if __name__ == "__main__":
    query = "Flights with long delays"
    print("\n🚀 Running FULL TEST on SAMPLE...")
    output = full_pipeline(query)

    print("\n===== TOP RESULTS =====")
    for r in output:
        print(r)
